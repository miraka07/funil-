"use client"

import { useState, useEffect } from "react"
import { AlertTriangle, Clock } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

export function UrgencyBanner() {
  const [timeLeft, setTimeLeft] = useState(847)

  useEffect(() => {
    const interval = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0))
    }, 1000)

    return () => clearInterval(interval)
  }, [])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  return (
    <Alert className="border-yellow-500/50 bg-gradient-to-r from-yellow-900/60 to-orange-900/60 animate-pulse">
      <AlertTriangle className="h-4 w-4 text-yellow-400" />
      <AlertDescription className="text-yellow-200 text-sm flex items-center justify-between">
        <span>
          <strong>⚡ DEMONSTRAÇÃO LIMITADA:</strong> Apenas {Math.floor(Math.random() * 50) + 10} pessoas podem testar
          hoje
        </span>
        <div className="flex items-center gap-1 text-yellow-300 font-mono text-xs">
          <Clock className="h-3 w-3" />
          {formatTime(timeLeft)}
        </div>
      </AlertDescription>
    </Alert>
  )
}
