"use client"

import { useState } from "react"
import { Info, ArrowRight, Target, MapPin, Sparkles, ExternalLink, Zap, Shield, Eye, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import React from "react"

interface Props {
  data: {
    customMessage: string
    linkName: string
    redirectUrl: string
    camouflage: string
    previewData: {
      profileName: string
      contentTitle: string
      contentDescription: string
      hashtags: string
      contentType: "video" | "photo" | "story" | "news" | "music" | "post"
    }
  }
  onDone: (city: string) => void
  onEdit: () => void
}

const animationStyles = `
  @keyframes fade-in {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
  }
  
  @keyframes fade-in-delay {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
  }
  
  @keyframes slide-in-left {
    from { opacity: 0; transform: translateX(-50px); }
    to { opacity: 1; transform: translateX(0); }
  }
  
  @keyframes slide-in-right {
    from { opacity: 0; transform: translateX(50px); }
    to { opacity: 1; transform: translateX(0); }
  }
  
  @keyframes fade-in-up {
    from { opacity: 0; transform: translateY(30px); }
    to { opacity: 1; transform: translateY(0); }
  }
  
  .animate-fade-in {
    animation: fade-in 0.8s ease-out forwards;
  }
  
  .animate-fade-in-delay {
    animation: fade-in-delay 1s ease-out 0.3s forwards;
    opacity: 0;
  }
  
  .animate-slide-in-left {
    animation: slide-in-left 0.8s ease-out forwards;
    opacity: 0;
  }
  
  .animate-slide-in-right {
    animation: slide-in-right 0.8s ease-out forwards;
    opacity: 0;
  }
  
  .animate-fade-in-up {
    animation: fade-in-up 0.8s ease-out forwards;
    opacity: 0;
  }
`

export function Step3Capture({ data, onDone, onEdit }: Props) {
  const [selectedCity] = useState("São Paulo, SP")
  const redirectUrl = data.redirectUrl

  // Add the style tag here
  React.useEffect(() => {
    const styleElement = document.createElement("style")
    styleElement.textContent = animationStyles
    document.head.appendChild(styleElement)
    return () => document.head.removeChild(styleElement)
  }, [])

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const handleComplete = () => {
    // Redireciona para o checkout
    window.open("https://linkmagico.vercel.app/checkout", "_blank")
  }

  return (
    <Card className="bg-gradient-to-br from-blue-900/50 to-indigo-800/30 border-blue-500/30 backdrop-blur-lg">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-3 text-lg text-white">
          <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center text-sm font-bold">
            3
          </div>
          Resultado da Captura com o Link Inteligente
          <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30 ml-auto">
            <Target className="h-3 w-3 mr-1" />
            Pronto
          </Badge>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-6 px-4 sm:px-6">
        {/* Como Funciona o Processo */}
        <div className="bg-gradient-to-r from-emerald-900/80 to-green-900/80 border-2 border-emerald-400/50 rounded-xl p-6 relative overflow-hidden">
          {/* Animated background effects */}
          <div className="absolute inset-0 bg-gradient-to-r from-emerald-500/10 to-green-500/10 animate-pulse"></div>
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-400 via-green-400 to-emerald-400 animate-pulse"></div>
          <div className="absolute -top-10 -right-10 w-20 h-20 bg-emerald-400/20 rounded-full animate-ping"></div>
          <div
            className="absolute -bottom-10 -left-10 w-16 h-16 bg-green-400/20 rounded-full animate-ping"
            style={{ animationDelay: "1s" }}
          ></div>

          <div className="relative z-10">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-gradient-to-r from-emerald-400 to-green-400 rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce shadow-lg shadow-emerald-500/50">
                <Zap className="h-8 w-8 text-white animate-pulse" />
              </div>
              <h3 className="text-white font-black text-xl mb-2 animate-fade-in">🎯 Como Funciona a Magia</h3>
              <p className="text-emerald-200 text-lg animate-fade-in-delay">
                Veja como seu link inteligente captura a localização de forma{" "}
                <span className="font-bold text-yellow-300 animate-pulse">100% INVISÍVEL</span>
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Etapa 1 - Enhanced */}
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-emerald-400/30 hover:scale-105 hover:shadow-xl hover:shadow-blue-500/30 transition-all duration-500 transform hover:-translate-y-2 animate-slide-in-left relative overflow-hidden group">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-cyan-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div className="absolute top-0 right-0 w-8 h-8 bg-blue-400/20 rounded-full animate-ping"></div>
                <div className="relative z-10">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center animate-pulse shadow-lg shadow-blue-500/50 group-hover:animate-spin">
                      <Eye className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <div className="text-white font-bold text-lg group-hover:text-blue-300 transition-colors">
                        1. CLIQUE INOCENTE
                      </div>
                      <div className="text-emerald-200 text-sm">Pessoa clica no link camuflado</div>
                    </div>
                  </div>
                  <p className="text-emerald-100 text-sm leading-relaxed">
                    A pessoa vê um link{" "}
                    <span className="font-bold text-yellow-300 animate-pulse">completamente normal</span> do{" "}
                    {redirectUrl} e clica sem suspeitar de nada.
                  </p>
                </div>
              </div>

              {/* Etapa 2 - Enhanced */}
              <div
                className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-yellow-400/30 hover:scale-105 hover:shadow-xl hover:shadow-yellow-500/30 transition-all duration-500 transform hover:-translate-y-2 animate-slide-in-right relative overflow-hidden group"
                style={{ animationDelay: "0.2s" }}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-yellow-500/10 to-orange-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div
                  className="absolute bottom-0 left-0 w-6 h-6 bg-yellow-400/20 rounded-full animate-ping"
                  style={{ animationDelay: "0.5s" }}
                ></div>
                <div className="relative z-10">
                  <div className="flex items-center gap-3 mb-3">
                    <div
                      className="w-12 h-12 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full flex items-center justify-center animate-pulse shadow-lg shadow-yellow-500/50 group-hover:animate-bounce"
                      style={{ animationDelay: "0.5s" }}
                    >
                      <MapPin className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <div className="text-white font-bold text-lg group-hover:text-yellow-300 transition-colors">
                        2. CAPTURA INVISÍVEL
                      </div>
                      <div className="text-emerald-200 text-sm">GPS capturado em milissegundos</div>
                    </div>
                  </div>
                  <p className="text-emerald-100 text-sm leading-relaxed">
                    Nosso sistema <span className="font-bold text-yellow-300 animate-pulse">captura discretamente</span>{" "}
                    a localização GPS exata com precisão de ±3 metros.
                  </p>
                </div>
              </div>

              {/* Etapa 3 - Enhanced */}
              <div
                className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-purple-400/30 hover:scale-105 hover:shadow-xl hover:shadow-purple-500/30 transition-all duration-500 transform hover:-translate-y-2 animate-slide-in-left relative overflow-hidden group"
                style={{ animationDelay: "0.4s" }}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 to-pink-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div
                  className="absolute top-2 left-2 w-4 h-4 bg-purple-400/20 rounded-full animate-ping"
                  style={{ animationDelay: "1s" }}
                ></div>
                <div className="relative z-10">
                  <div className="flex items-center gap-3 mb-3">
                    <div
                      className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center animate-pulse shadow-lg shadow-purple-500/50 group-hover:animate-pulse"
                      style={{ animationDelay: "1s" }}
                    >
                      <ExternalLink className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <div className="text-white font-bold text-lg group-hover:text-purple-300 transition-colors">
                        3. REDIRECIONAMENTO
                      </div>
                      <div className="text-emerald-200 text-sm">Vai para o destino normal</div>
                    </div>
                  </div>
                  <p className="text-emerald-100 text-sm leading-relaxed">
                    A pessoa é{" "}
                    <span className="font-bold text-yellow-300 animate-pulse">automaticamente redirecionada</span> para
                    o {redirectUrl} como se nada tivesse acontecido.
                  </p>
                </div>
              </div>

              {/* Etapa 4 - Enhanced */}
              <div
                className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-green-400/30 hover:scale-105 hover:shadow-xl hover:shadow-green-500/30 transition-all duration-500 transform hover:-translate-y-2 animate-slide-in-right relative overflow-hidden group"
                style={{ animationDelay: "0.6s" }}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-green-500/10 to-emerald-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div
                  className="absolute bottom-2 right-2 w-5 h-5 bg-green-400/20 rounded-full animate-ping"
                  style={{ animationDelay: "1.5s" }}
                ></div>
                <div className="relative z-10">
                  <div className="flex items-center gap-3 mb-3">
                    <div
                      className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center animate-pulse shadow-lg shadow-green-500/50 group-hover:animate-bounce"
                      style={{ animationDelay: "1.5s" }}
                    >
                      <Shield className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <div className="text-white font-bold text-lg group-hover:text-green-300 transition-colors">
                        4. VOCÊ RECEBE TUDO
                      </div>
                      <div className="text-emerald-200 text-sm">Localização exata no aplicativo</div>
                    </div>
                  </div>
                  <p className="text-emerald-100 text-sm leading-relaxed">
                    Você recebe <span className="font-bold text-yellow-300 animate-pulse">instantaneamente</span> a
                    localização exata, endereço completo e horário do acesso.
                  </p>
                </div>
              </div>
            </div>

            {/* Destaque da Eficácia - Enhanced */}
            <div
              className="mt-6 bg-gradient-to-r from-yellow-900/60 to-orange-900/60 border-2 border-yellow-400/50 rounded-lg p-4 text-center relative overflow-hidden animate-fade-in-up"
              style={{ animationDelay: "0.8s" }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-yellow-400/10 to-orange-400/10 animate-pulse"></div>
              <div className="absolute -top-2 -right-2 w-4 h-4 bg-yellow-400/30 rounded-full animate-ping"></div>
              <div
                className="absolute -bottom-2 -left-2 w-3 h-3 bg-orange-400/30 rounded-full animate-ping"
                style={{ animationDelay: "0.5s" }}
              ></div>
              <div className="relative z-10">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Clock className="h-5 w-5 text-yellow-400 animate-pulse" />
                  <span className="text-yellow-300 font-black text-sm animate-pulse">
                    PROCESSO COMPLETO EM MENOS DE 3 SEGUNDOS
                  </span>
                </div>
                <p className="text-yellow-200 text-sm">
                  <span className="font-bold animate-pulse">100% indetectável</span> •{" "}
                  <span className="font-bold animate-pulse" style={{ animationDelay: "0.2s" }}>
                    Precisão militar
                  </span>{" "}
                  •{" "}
                  <span className="font-bold animate-pulse" style={{ animationDelay: "0.4s" }}>
                    Funciona sempre
                  </span>
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Informação sobre o Link */}
        <Alert className="border-blue-500/30 bg-blue-900/30 backdrop-blur-sm">
          <Info className="h-4 w-4 text-blue-400" />
          <AlertDescription className="text-blue-200 leading-relaxed text-sm">
            <strong>Link Inteligente Configurado:</strong> Sua configuração está pronta! O link aparenta ser um conteúdo
            comum da sua escolha, mas captura discretamente a localização antes do redirecionamento.
          </AlertDescription>
        </Alert>

        {/* Funcionalidades Principais */}
        <div className="bg-purple-900/30 p-4 rounded-lg border border-purple-500/20">
          <h4 className="text-purple-300 font-bold mb-3 text-center">🎯 Funcionalidades do Seu Link</h4>
          <div className="grid grid-cols-2 gap-4 text-center">
            <div>
              <div className="text-purple-400 font-bold text-lg">100%</div>
              <div className="text-purple-200 text-sm">Discreto</div>
            </div>
            <div>
              <div className="text-purple-400 font-bold text-lg">±3m</div>
              <div className="text-purple-200 text-sm">Precisão GPS</div>
            </div>
            <div>
              <div className="text-purple-400 font-bold text-lg">Instantâneo</div>
              <div className="text-purple-200 text-sm">Captura rápida</div>
            </div>
            <div>
              <div className="text-purple-400 font-bold text-lg">Camuflado</div>
              <div className="text-purple-200 text-sm">URL real</div>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="bg-gradient-to-r from-purple-900/80 to-pink-900/80 border border-purple-500/30 rounded-xl p-4 sm:p-6 text-center">
          <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-3 sm:mb-4">
            <Sparkles className="h-6 w-6 sm:h-8 sm:w-8 text-white" />
          </div>
          <h3 className="text-white font-bold text-lg sm:text-2xl mb-2 sm:mb-3">Configuração Finalizada!</h3>
          <p className="text-purple-200 mb-4 sm:mb-6 leading-relaxed text-sm sm:text-base">
            Seu link inteligente está configurado e pronto para uso. Acesse a versão completa para gerar e usar quantos
            links quiser.
          </p>

          <Button
            onClick={handleComplete}
            className="w-full sm:w-auto bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold px-6 sm:px-8 py-3 sm:py-4 text-sm sm:text-lg rounded-full shadow-xl hover:shadow-purple-500/50 transition-all duration-300 transform hover:scale-105"
          >
            <ArrowRight className="h-4 w-4 sm:h-5 sm:w-5 mr-2" />
            Acessar Versão Completa
          </Button>
        </div>

        <div className="text-center">
          <p className="text-gray-400 text-xs sm:text-sm flex flex-wrap justify-center gap-1 sm:gap-2">
            <span>🔗 Link configurado</span>
            <span>•</span>
            <span>🎯 Pronto para usar</span>
            <span>•</span>
            <span>⚡ Acesso imediato</span>
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
