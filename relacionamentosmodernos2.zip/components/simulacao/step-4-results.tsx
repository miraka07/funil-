"use client"

import { useState, useEffect } from "react"
import {
  CheckCircle,
  Heart,
  Download,
  Zap,
  Shield,
  Crown,
  Target,
  Award,
  Clock,
  Timer,
  TrendingUp,
  X,
  ChevronRight,
  AlertTriangle,
  Users,
  Eye,
  Brain,
} from "lucide-react"
import { getCityCoordinates } from "./constants"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface Props {
  data: {
    customMessage: string
    linkName: string
    redirectUrl: string
    camouflage: string
  }
  capturedCity: string
}

type QuizStep = "hook" | "question1" | "question2" | "question3" | "question4" | "analysis" | "final"

interface UserProfile {
  type: "suspicious" | "anxious" | "betrayed" | "protective"
  intensity: "low" | "medium" | "high"
  urgency: "low" | "medium" | "high"
  answers: Record<string, string>
}

export function Step4Results({ data, capturedCity }: Props) {
  const [currentStep, setCurrentStep] = useState<QuizStep>("hook")
  const [timeLeft, setTimeLeft] = useState(27 * 60 + 43)
  const [spotsLeft, setSpotsLeft] = useState(23)
  const [recentPurchases, setRecentPurchases] = useState(2847)
  const [answers, setAnswers] = useState<Record<string, string>>({})
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
  const [showAnalysis, setShowAnalysis] = useState(false)

  const originalCoords = getCityCoordinates(capturedCity)
  const nearbyCoords = originalCoords
    ? {
        lat: (Number.parseFloat(originalCoords.lat) + (Math.random() - 0.5) * 0.008).toFixed(6),
        lng: (Number.parseFloat(originalCoords.lng) + (Math.random() - 0.5) * 0.008).toFixed(6),
      }
    : null

  // Timer e escassez dinâmica
  useEffect(() => {
    const interval = setInterval(() => {
      setTimeLeft((prev) => Math.max(0, prev - 1))
      if (Math.random() < 0.005) setSpotsLeft((prev) => Math.max(5, prev - 1))
      if (Math.random() < 0.01) setRecentPurchases((prev) => prev + 1)
    }, 1000)
    return () => clearInterval(interval)
  }, [])

  const minutes = Math.floor(timeLeft / 60)
  const seconds = timeLeft % 60

  // Análise do perfil do usuário baseado nas respostas
  const analyzeUserProfile = (userAnswers: Record<string, string>): UserProfile => {
    let type: UserProfile["type"] = "suspicious"
    let intensity: UserProfile["intensity"] = "medium"
    let urgency: UserProfile["urgency"] = "medium"

    // Determina o tipo baseado nas respostas
    if (userAnswers.q2 === "traicao" || userAnswers.q3 === "mentindo") {
      type = "betrayed"
      intensity = "high"
      urgency = "high"
    } else if (userAnswers.q2 === "ansiedade" || userAnswers.q4 === "sempre") {
      type = "anxious"
      intensity = userAnswers.q4 === "sempre" ? "high" : "medium"
      urgency = "high"
    } else if (userAnswers.q1 === "proteger" || userAnswers.q3 === "protegendo") {
      type = "protective"
      intensity = "medium"
      urgency = "medium"
    }

    // Ajusta urgência baseado na frequência dos problemas
    if (userAnswers.q4 === "sempre") urgency = "high"
    else if (userAnswers.q4 === "nunca") urgency = "low"

    return { type, intensity, urgency, answers: userAnswers }
  }

  const handleAnswer = (question: string, answer: string) => {
    const newAnswers = { ...answers, [question]: answer }
    setAnswers(newAnswers)

    // Avança automaticamente para próxima pergunta
    setTimeout(() => {
      if (currentStep === "question1") setCurrentStep("question2")
      else if (currentStep === "question2") setCurrentStep("question3")
      else if (currentStep === "question3") setCurrentStep("question4")
      else if (currentStep === "question4") {
        // Analisa o perfil e mostra análise
        const profile = analyzeUserProfile(newAnswers)
        setUserProfile(profile)
        setCurrentStep("analysis")

        // Após 3 segundos, vai para o resultado final
        setTimeout(() => {
          setShowAnalysis(true)
          setTimeout(() => {
            setCurrentStep("final")
          }, 2000)
        }, 3000)
      }
    }, 800)
  }

  const getPersonalizedContent = () => {
    if (!userProfile) return null

    const profiles = {
      suspicious: {
        title: "🕵️ PERFIL: INVESTIGADOR CAUTELOSO",
        description: "Você tem instintos aguçados e suspeita que algo não está certo",
        problem: "Suas suspeitas estão te consumindo por dentro",
        solution: "Você precisa de PROVAS CONCRETAS para ter paz de espírito",
        urgency: "Cada dia que passa sem saber a verdade é mais sofrimento",
        offer: "Acesso EXCLUSIVO ao GPS Premium + Relatórios Detalhados",
        discount: userProfile.urgency === "high" ? 90 : 86,
        color: "from-blue-500 to-cyan-500",
      },
      anxious: {
        title: "😰 PERFIL: CORAÇÃO ANSIOSO",
        description: "Você vive em constante preocupação e ansiedade",
        problem: "A ansiedade está destruindo sua qualidade de vida",
        solution: "Você precisa de TRANQUILIDADE e certeza para dormir em paz",
        urgency: "Sua saúde mental está em risco - precisa agir AGORA",
        offer: "Acesso EXCLUSIVO + Monitoramento 24h + Suporte Psicológico",
        discount: userProfile.urgency === "high" ? 92 : 88,
        color: "from-purple-500 to-pink-500",
      },
      betrayed: {
        title: "💔 PERFIL: CORAÇÃO FERIDO",
        description: "Você já foi traído(a) ou tem fortes indícios de traição",
        problem: "A dor da traição está destruindo sua capacidade de confiar",
        solution: "Você merece saber a VERDADE COMPLETA para tomar a decisão certa",
        urgency: "Não deixe que continuem te enganando - você merece respeito",
        offer: "Acesso EXCLUSIVO + Histórico Completo + Evidências Detalhadas",
        discount: 95,
        color: "from-red-500 to-orange-500",
      },
      protective: {
        title: "🛡️ PERFIL: GUARDIÃO DO RELACIONAMENTO",
        description: "Você quer proteger seu relacionamento e sua família",
        problem: "A incerteza está ameaçando tudo que você construiu",
        solution: "Você precisa de FERRAMENTAS para proteger o que é seu",
        urgency: "Proteja seu relacionamento antes que seja tarde demais",
        offer: "Acesso EXCLUSIVO + Proteção Familiar + Alertas Inteligentes",
        discount: 87,
        color: "from-green-500 to-emerald-500",
      },
    }

    return profiles[userProfile.type]
  }

  const handleCheckoutRedirect = () => {
    window.open("https://linkmagico.vercel.app/checkout", "_blank")
  }

  // Gancho inicial
  if (currentStep === "hook") {
    return (
      <Card className="bg-gradient-to-br from-emerald-900/50 to-green-800/30 border-emerald-500/30 backdrop-blur-lg">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-3 text-lg text-white">
            <div className="w-8 h-8 bg-gradient-to-r from-emerald-500 to-green-500 rounded-full flex items-center justify-center text-sm font-bold">
              4
            </div>
            Acesso à Ferramenta Completa
            <Badge className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30 ml-auto">
              <CheckCircle className="h-3 w-3 mr-1" />
              Disponível
            </Badge>
          </CardTitle>
        </CardHeader>

        <CardContent className="space-y-6 px-4 sm:px-6">
          {/* Sucesso Dramático Simplificado */}
          <div className="bg-gradient-to-r from-green-900/80 to-emerald-900/80 border-2 border-green-400/50 rounded-xl p-6 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-green-500/10 to-emerald-500/10 animate-pulse"></div>
            <div className="relative z-10 text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-green-400 to-emerald-400 rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce">
                <CheckCircle className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-white font-black text-2xl mb-3">🎉 FUNCIONOU PERFEITAMENTE!</h3>
              <p className="text-green-200 mb-4">
                Você acabou de ver como é <span className="font-bold text-yellow-300">FÁCIL</span> descobrir a
                localização exata de qualquer pessoa!
              </p>
            </div>
          </div>

          {/* GANCHO - Segurança e Exclusividade */}
          <div className="bg-gradient-to-r from-red-900/60 to-orange-900/60 border-2 border-red-400/50 rounded-lg p-4 mb-4">
            <div className="flex items-center justify-center gap-2 mb-3">
              <Shield className="h-6 w-6 text-red-400 animate-pulse" />
              <span className="text-red-300 font-black text-lg">ATENÇÃO: FERRAMENTA PODEROSA</span>
            </div>
            <p className="text-red-200 text-sm leading-relaxed mb-3">
              Esta tecnologia é <span className="font-bold text-yellow-300">EXTREMAMENTE PODEROSA</span> e pode ser
              usada de forma inadequada. Por questões de <span className="font-bold">SEGURANÇA E RESPONSABILIDADE</span>
              , não liberamos acesso para qualquer pessoa.
            </p>
            <div className="bg-yellow-900/40 border border-yellow-500/30 rounded-lg p-3">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="h-5 w-5 text-yellow-400 animate-pulse" />
                <span className="text-yellow-300 font-bold text-sm">PROCESSO DE QUALIFICAÇÃO OBRIGATÓRIO</span>
              </div>
              <p className="text-yellow-200 text-xs leading-relaxed">
                Apenas <span className="font-bold">{spotsLeft} pessoas por dia</span> passam pelo nosso processo de
                qualificação. Precisamos garantir que você usará esta ferramenta de forma{" "}
                <span className="font-bold">ÉTICA E RESPONSÁVEL</span>.
              </p>
            </div>
          </div>

          {/* Botão para iniciar processo de qualificação */}
          <Button
            onClick={() => setCurrentStep("question1")}
            className="w-full bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600 text-white font-bold py-4 text-sm sm:text-lg rounded-xl shadow-lg transition-all duration-300 hover:scale-105 animate-pulse"
          >
            <Shield className="h-4 w-4 sm:h-5 sm:w-5 mr-2 flex-shrink-0" />
            <span className="truncate">INICIAR PROCESSO DE QUALIFICAÇÃO</span>
          </Button>

          <div className="text-center">
            <p className="text-gray-400 text-sm mb-2">
              🔒 Processo rápido e seguro • ⏱️ Apenas 4 perguntas • 🎯 Análise personalizada
            </p>
            <div className="flex items-center justify-center gap-2">
              <div className="flex items-center gap-1">
                <Users className="h-4 w-4 text-red-400" />
                <span className="text-red-300 text-xs font-medium">{spotsLeft} vagas restantes hoje</span>
              </div>
              <div className="w-1 h-1 bg-gray-500 rounded-full"></div>
              <div className="flex items-center gap-1">
                <Timer className="h-4 w-4 text-yellow-400 animate-pulse" />
                <span className="text-yellow-300 text-xs font-medium">
                  {String(minutes).padStart(2, "0")}:{String(seconds).padStart(2, "0")} restantes
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  // Pergunta 1 - Motivação (SEM indicador de etapa)
  if (currentStep === "question1") {
    return (
      <Card className="bg-gradient-to-br from-purple-900/50 to-indigo-800/30 border-purple-500/30 backdrop-blur-lg">
        <CardContent className="p-6">
          <div className="text-center mb-6">
            <h3 className="text-white font-bold text-xl mb-2">🎯 Análise Personalizada</h3>
            <p className="text-purple-200 text-sm">Vamos entender seu perfil único...</p>
          </div>

          <div className="bg-white/10 p-4 rounded-lg border border-purple-400/30 mb-6">
            <h4 className="text-white font-bold text-lg mb-4 text-center">
              "O que te motivou a testar nossa ferramenta hoje?"
            </h4>

            <div className="space-y-3">
              <button
                onClick={() => handleAnswer("q1", "suspeita")}
                className="w-full bg-orange-900/40 border-2 border-orange-400/50 rounded-lg p-4 text-left hover:bg-orange-900/60 transition-all group"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <Eye className="h-5 w-5 text-orange-400" />
                      <span className="text-orange-300 font-bold">Tenho suspeitas</span>
                    </div>
                    <p className="text-orange-200 text-sm">Algo não está batendo no comportamento do meu parceiro(a)</p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-orange-400 group-hover:translate-x-1 transition-transform" />
                </div>
              </button>

              <button
                onClick={() => handleAnswer("q1", "proteger")}
                className="w-full bg-green-900/40 border border-green-500/30 rounded-lg p-4 text-left hover:bg-green-900/60 transition-all group"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <Shield className="h-5 w-5 text-green-400" />
                      <span className="text-green-300 font-bold">Quero proteger meu relacionamento</span>
                    </div>
                    <p className="text-green-200 text-sm">Prefiro prevenir problemas antes que aconteçam</p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-green-400 group-hover:translate-x-1 transition-transform" />
                </div>
              </button>

              <button
                onClick={() => handleAnswer("q1", "curiosidade")}
                className="w-full bg-blue-900/40 border border-blue-500/30 rounded-lg p-4 text-left hover:bg-blue-900/60 transition-all group"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <Brain className="h-5 w-5 text-blue-400" />
                      <span className="text-blue-300 font-bold">Curiosidade sobre a tecnologia</span>
                    </div>
                    <p className="text-blue-200 text-sm">Queria ver como funciona essa ferramenta</p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-blue-400 group-hover:translate-x-1 transition-transform" />
                </div>
              </button>

              <button
                onClick={() => handleAnswer("q1", "confirmacao")}
                className="w-full bg-red-900/40 border border-red-500/30 rounded-lg p-4 text-left hover:bg-red-900/60 transition-all group"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <AlertTriangle className="h-5 w-5 text-red-400" />
                      <span className="text-red-300 font-bold">Preciso de confirmação</span>
                    </div>
                    <p className="text-red-200 text-sm">Já tenho suspeitas e quero provas concretas</p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-red-400 group-hover:translate-x-1 transition-transform" />
                </div>
              </button>
            </div>
          </div>

          <div className="text-center">
            <p className="text-purple-200 text-sm">
              <strong>Analisando seu perfil...</strong> Esta informação nos ajuda a personalizar sua experiência
            </p>
          </div>
        </CardContent>
      </Card>
    )
  }

  // Pergunta 2 - Problema Principal (SEM indicador de etapa)
  if (currentStep === "question2") {
    return (
      <Card className="bg-gradient-to-br from-blue-900/50 to-cyan-800/30 border-blue-500/30 backdrop-blur-lg">
        <CardContent className="p-6">
          <div className="text-center mb-6">
            <h3 className="text-white font-bold text-xl mb-2">💭 Diagnóstico Emocional</h3>
            <p className="text-blue-200 text-sm">Identificando seu maior desafio...</p>
          </div>

          <div className="bg-white/10 p-4 rounded-lg border border-blue-400/30 mb-6">
            <h4 className="text-white font-bold text-lg mb-4 text-center">
              "Qual é o maior problema que você enfrenta no seu relacionamento?"
            </h4>

            <div className="space-y-3">
              <button
                onClick={() => handleAnswer("q2", "mentiras")}
                className="w-full bg-red-900/40 border-2 border-red-400/50 rounded-lg p-4 text-left hover:bg-red-900/60 transition-all group"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <X className="h-5 w-5 text-red-400" />
                      <span className="text-red-300 font-bold">Mentiras constantes</span>
                    </div>
                    <p className="text-red-200 text-sm">Meu parceiro(a) mente sobre onde está e o que faz</p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-red-400 group-hover:translate-x-1 transition-transform" />
                </div>
              </button>

              <button
                onClick={() => handleAnswer("q2", "ansiedade")}
                className="w-full bg-purple-900/40 border border-purple-500/30 rounded-lg p-4 text-left hover:bg-purple-900/60 transition-all group"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <Heart className="h-5 w-5 text-purple-400" />
                      <span className="text-purple-300 font-bold">Ansiedade e insegurança</span>
                    </div>
                    <p className="text-purple-200 text-sm">Vivo preocupado(a) e não consigo relaxar</p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-purple-400 group-hover:translate-x-1 transition-transform" />
                </div>
              </button>

              <button
                onClick={() => handleAnswer("q2", "traicao")}
                className="w-full bg-orange-900/40 border border-orange-500/30 rounded-lg p-4 text-left hover:bg-orange-900/60 transition-all group"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <AlertTriangle className="h-5 w-5 text-orange-400" />
                      <span className="text-orange-300 font-bold">Suspeita de traição</span>
                    </div>
                    <p className="text-orange-200 text-sm">Tenho fortes indícios de que estou sendo traído(a)</p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-orange-400 group-hover:translate-x-1 transition-transform" />
                </div>
              </button>

              <button
                onClick={() => handleAnswer("q2", "brigas")}
                className="w-full bg-yellow-900/40 border border-yellow-500/30 rounded-lg p-4 text-left hover:bg-yellow-900/60 transition-all group"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <Users className="h-5 w-5 text-yellow-400" />
                      <span className="text-yellow-300 font-bold">Brigas por desconfiança</span>
                    </div>
                    <p className="text-yellow-200 text-sm">Discutimos constantemente por falta de transparência</p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-yellow-400 group-hover:translate-x-1 transition-transform" />
                </div>
              </button>
            </div>
          </div>

          <div className="text-center">
            <p className="text-blue-200 text-sm">
              <strong>73%</strong> dos relacionamentos terminam por problemas de confiança
            </p>
          </div>
        </CardContent>
      </Card>
    )
  }

  // Pergunta 3 - Situação Atual (SEM indicador de etapa)
  if (currentStep === "question3") {
    return (
      <Card className="bg-gradient-to-br from-green-900/50 to-emerald-800/30 border-green-500/30 backdrop-blur-lg">
        <CardContent className="p-6">
          <div className="text-center mb-6">
            <h3 className="text-white font-bold text-xl mb-2">🔍 Situação Atual</h3>
            <p className="text-green-200 text-sm">Entendendo seu momento...</p>
          </div>

          <div className="bg-white/10 p-4 rounded-lg border border-green-400/30 mb-6">
            <h4 className="text-white font-bold text-lg mb-4 text-center">
              "Como você se sente em relação ao comportamento do seu parceiro(a)?"
            </h4>

            <div className="space-y-3">
              <button
                onClick={() => handleAnswer("q3", "mentindo")}
                className="w-full bg-red-900/40 border-2 border-red-400/50 rounded-lg p-4 text-left hover:bg-red-900/60 transition-all group"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <AlertTriangle className="h-5 w-5 text-red-400" />
                      <span className="text-red-300 font-bold">Tenho certeza que está mentindo</span>
                    </div>
                    <p className="text-red-200 text-sm">As histórias não batem, preciso de provas</p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-red-400 group-hover:translate-x-1 transition-transform" />
                </div>
              </button>

              <button
                onClick={() => handleAnswer("q3", "desconfiado")}
                className="w-full bg-orange-900/40 border border-orange-500/30 rounded-lg p-4 text-left hover:bg-orange-900/60 transition-all group"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <Eye className="h-5 w-5 text-orange-400" />
                      <span className="text-orange-300 font-bold">Desconfiado(a) mas sem certeza</span>
                    </div>
                    <p className="text-orange-200 text-sm">Algo não está certo, mas não tenho provas</p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-orange-400 group-hover:translate-x-1 transition-transform" />
                </div>
              </button>

              <button
                onClick={() => handleAnswer("q3", "protegendo")}
                className="w-full bg-blue-900/40 border border-blue-500/30 rounded-lg p-4 text-left hover:bg-blue-900/60 transition-all group"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <Shield className="h-5 w-5 text-blue-400" />
                      <span className="text-blue-300 font-bold">Quero proteger nosso relacionamento</span>
                    </div>
                    <p className="text-blue-200 text-sm">Prefiro ter transparência para evitar problemas</p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-blue-400 group-hover:translate-x-1 transition-transform" />
                </div>
              </button>

              <button
                onClick={() => handleAnswer("q3", "confuso")}
                className="w-full bg-purple-900/40 border border-purple-500/30 rounded-lg p-4 text-left hover:bg-purple-900/60 transition-all group"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <Brain className="h-5 w-5 text-purple-400" />
                      <span className="text-purple-300 font-bold">Confuso(a) e perdido(a)</span>
                    </div>
                    <p className="text-purple-200 text-sm">Não sei mais em quem ou no que acreditar</p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-purple-400 group-hover:translate-x-1 transition-transform" />
                </div>
              </button>
            </div>
          </div>

          <div className="text-center">
            <p className="text-green-200 text-sm">
              <strong>92%</strong> das pessoas que desconfiam do parceiro estão certas
            </p>
          </div>
        </CardContent>
      </Card>
    )
  }

  // Pergunta 4 - Urgência (SEM indicador de etapa)
  if (currentStep === "question4") {
    return (
      <Card className="bg-gradient-to-br from-yellow-900/50 to-orange-800/30 border-yellow-500/30 backdrop-blur-lg">
        <CardContent className="p-6">
          <div className="text-center mb-6">
            <h3 className="text-white font-bold text-xl mb-2">⏰ Nível de Urgência</h3>
            <p className="text-yellow-200 text-sm">Última pergunta para personalizar sua solução...</p>
          </div>

          <div className="bg-white/10 p-4 rounded-lg border border-yellow-400/30 mb-6">
            <h4 className="text-white font-bold text-lg mb-4 text-center">
              "Com que frequência você se sente ansioso(a) ou preocupado(a) com seu relacionamento?"
            </h4>

            <div className="space-y-3">
              <button
                onClick={() => handleAnswer("q4", "sempre")}
                className="w-full bg-red-900/40 border-2 border-red-400/50 rounded-lg p-4 text-left hover:bg-red-900/60 transition-all group"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <AlertTriangle className="h-5 w-5 text-red-400 animate-pulse" />
                      <span className="text-red-300 font-bold">Todos os dias - é constante</span>
                    </div>
                    <p className="text-red-200 text-sm">Não consigo parar de pensar nisso, está me consumindo</p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-red-400 group-hover:translate-x-1 transition-transform" />
                </div>
              </button>

              <button
                onClick={() => handleAnswer("q4", "frequente")}
                className="w-full bg-orange-900/40 border border-orange-500/30 rounded-lg p-4 text-left hover:bg-orange-900/60 transition-all group"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <Clock className="h-5 w-5 text-orange-400" />
                      <span className="text-orange-300 font-bold">Várias vezes por semana</span>
                    </div>
                    <p className="text-orange-200 text-sm">Especialmente quando ele(a) sai ou demora para responder</p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-orange-400 group-hover:translate-x-1 transition-transform" />
                </div>
              </button>

              <button
                onClick={() => handleAnswer("q4", "ocasional")}
                className="w-full bg-yellow-900/40 border border-yellow-500/30 rounded-lg p-4 text-left hover:bg-yellow-900/60 transition-all group"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <Heart className="h-5 w-5 text-yellow-400" />
                      <span className="text-yellow-300 font-bold">Às vezes, em situações específicas</span>
                    </div>
                    <p className="text-yellow-200 text-sm">Quando algo não bate ou parece estranho</p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-yellow-400 group-hover:translate-x-1 transition-transform" />
                </div>
              </button>

              <button
                onClick={() => handleAnswer("q4", "raramente")}
                className="w-full bg-green-900/40 border border-green-500/30 rounded-lg p-4 text-left hover:bg-green-900/60 transition-all group"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <Shield className="h-5 w-5 text-green-400" />
                      <span className="text-green-300 font-bold">Raramente - mais por prevenção</span>
                    </div>
                    <p className="text-green-200 text-sm">Quero ter essa ferramenta como segurança</p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-green-400 group-hover:translate-x-1 transition-transform" />
                </div>
              </button>
            </div>
          </div>

          <div className="text-center">
            <p className="text-yellow-200 text-sm">
              <strong>Analisando suas respostas...</strong> Preparando sua solução personalizada
            </p>
          </div>
        </CardContent>
      </Card>
    )
  }

  // Análise em tempo real
  if (currentStep === "analysis") {
    return (
      <Card className="bg-gradient-to-br from-indigo-900/50 to-purple-800/30 border-indigo-500/30 backdrop-blur-lg">
        <CardContent className="p-6">
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-indigo-400 to-purple-400 rounded-full flex items-center justify-center mx-auto mb-6 animate-spin">
              <Brain className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-white font-black text-2xl mb-4">🧠 ANALISANDO SEU PERFIL...</h3>

            {!showAnalysis ? (
              <div className="space-y-4">
                <div className="bg-white/10 p-4 rounded-lg">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <div className="w-3 h-3 bg-blue-400 rounded-full animate-pulse"></div>
                    <span className="text-blue-200">Processando suas respostas...</span>
                  </div>
                </div>
                <div className="bg-white/10 p-4 rounded-lg">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <div
                      className="w-3 h-3 bg-green-400 rounded-full animate-pulse"
                      style={{ animationDelay: "0.5s" }}
                    ></div>
                    <span className="text-green-200">Identificando seu perfil psicológico...</span>
                  </div>
                </div>
                <div className="bg-white/10 p-4 rounded-lg">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <div
                      className="w-3 h-3 bg-purple-400 rounded-full animate-pulse"
                      style={{ animationDelay: "1s" }}
                    ></div>
                    <span className="text-purple-200">Calculando sua solução ideal...</span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="bg-green-900/30 border border-green-500/30 rounded-lg p-4">
                  <CheckCircle className="h-8 w-8 text-green-400 mx-auto mb-2" />
                  <h4 className="text-green-300 font-bold text-lg">ANÁLISE CONCLUÍDA!</h4>
                  <p className="text-green-200 text-sm">Seu perfil foi identificado com 98.7% de precisão</p>
                </div>
                <p className="text-indigo-200">Preparando sua oferta personalizada...</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    )
  }

  // Resultado Final Personalizado
  const personalizedContent = getPersonalizedContent()
  if (!personalizedContent) return null

  return (
    <Card className="bg-gradient-to-br from-purple-900/50 to-pink-800/30 border-purple-500/30 backdrop-blur-lg">
      <CardContent className="p-4 sm:p-6 space-y-4 sm:space-y-6">
        {/* Header com Timer */}
        <div className="bg-gradient-to-r from-red-600/80 to-orange-600/80 border border-red-400/50 rounded-lg p-3 sm:p-4">
          <div className="flex items-center justify-center gap-4 sm:gap-8 text-center">
            <div className="flex items-center gap-2">
              <Timer className="h-4 w-4 sm:h-5 sm:w-5 text-yellow-300 animate-pulse" />
              <div>
                <div className="text-yellow-300 font-bold text-lg sm:text-xl">
                  {String(minutes).padStart(2, "0")}:{String(seconds).padStart(2, "0")}
                </div>
                <div className="text-red-200 text-xs">Oferta expira em</div>
              </div>
            </div>
            <div className="text-center">
              <div className="text-orange-300 font-bold text-lg sm:text-xl">{spotsLeft}</div>
              <div className="text-red-200 text-xs">Vagas restantes</div>
            </div>
          </div>
        </div>

        {/* Resultado Personalizado */}
        <div
          className={`bg-gradient-to-r ${personalizedContent.color}/20 border-2 border-current rounded-xl p-4 sm:p-6 relative overflow-hidden`}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-current/5 to-current/10 animate-pulse"></div>
          <div className="relative z-10 text-center">
            <div
              className={`w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-r ${personalizedContent.color} rounded-full flex items-center justify-center mx-auto mb-3 sm:mb-4 animate-pulse`}
            >
              <Crown className="h-6 w-6 sm:h-8 sm:w-8 text-white" />
            </div>
            <h3 className="text-white font-black text-lg sm:text-2xl mb-2">{personalizedContent.title}</h3>
            <p className="text-gray-200 text-sm sm:text-base mb-4">{personalizedContent.description}</p>

            <div className="bg-red-900/40 border border-red-500/30 rounded-lg p-3 sm:p-4 mb-4">
              <h4 className="text-red-300 font-bold mb-2">🚨 SEU MAIOR PROBLEMA:</h4>
              <p className="text-red-200 text-sm">{personalizedContent.problem}</p>
            </div>

            <div className="bg-green-900/40 border border-green-500/30 rounded-lg p-3 sm:p-4">
              <h4 className="text-green-300 font-bold mb-2">✅ SUA SOLUÇÃO IDEAL:</h4>
              <p className="text-green-200 text-sm">{personalizedContent.solution}</p>
            </div>
          </div>
        </div>

        {/* Oferta Exclusiva Personalizada */}
        <div className="bg-gradient-to-r from-yellow-900/40 to-orange-900/40 border-2 border-yellow-400/50 rounded-xl p-4 text-center relative">
          <div className="absolute -top-2 -right-2 bg-yellow-500 text-black text-xs font-bold px-2 py-1 rounded-full animate-pulse">
            SÓ PARA VOCÊ
          </div>
          <h4 className="text-white font-black text-lg sm:text-xl mb-2">🎁 OFERTA EXCLUSIVA PERSONALIZADA</h4>
          <p className="text-yellow-200 text-sm mb-3">{personalizedContent.offer}</p>

          <div className="flex items-center justify-center gap-2 sm:gap-4 mb-2">
            <div className="text-red-300 text-lg sm:text-xl line-through">R$ 197,00</div>
            <div className="text-green-300 text-2xl sm:text-3xl font-bold">R$ 27,00</div>
          </div>
          <div className="text-green-200 text-sm">
            <div className="flex items-center justify-center gap-2 mb-1">
              <span className="bg-red-500/20 text-red-300 px-2 py-1 rounded-full text-xs font-bold animate-pulse">
                {personalizedContent.discount}% OFF
              </span>
              <span className="text-yellow-300 font-semibold">DESCONTO PERSONALIZADO</span>
            </div>
            <div className="text-green-300 font-medium">Você economiza R$ {197 - 27},00 hoje!</div>
          </div>
        </div>

        {/* Urgência Personalizada */}
        <div className="bg-gradient-to-r from-red-600/80 to-orange-600/80 border border-red-400/50 rounded-lg p-3 sm:p-4 text-center">
          <h4 className="text-white font-black text-base sm:text-xl mb-2">⚠️ URGÊNCIA PARA SEU PERFIL</h4>
          <p className="text-red-100 text-xs sm:text-sm mb-3 leading-relaxed">{personalizedContent.urgency}</p>
          <div className="flex items-center justify-center gap-2 text-orange-200">
            <Clock className="h-4 w-4 animate-pulse" />
            <span className="font-semibold text-sm">Não deixe para amanhã o que pode resolver hoje</span>
          </div>
        </div>

        {/* Benefícios Grid Compacto */}
        <div className="grid grid-cols-2 gap-2 sm:gap-3">
          <div className="bg-white/10 p-2 sm:p-3 rounded-lg text-center">
            <Target className="h-4 w-4 sm:h-6 sm:w-6 text-green-400 mx-auto mb-1 sm:mb-2" />
            <div className="text-white font-medium text-xs sm:text-sm">GPS Sem Blur</div>
            <div className="text-gray-300 text-xs">Localização exata</div>
          </div>
          <div className="bg-white/10 p-2 sm:p-3 rounded-lg text-center">
            <Zap className="h-4 w-4 sm:h-6 sm:w-6 text-blue-400 mx-auto mb-1 sm:mb-2" />
            <div className="text-white font-medium text-xs sm:text-sm">Links Ilimitados</div>
            <div className="text-gray-300 text-xs">Use sem limite</div>
          </div>
          <div className="bg-white/10 p-2 sm:p-3 rounded-lg text-center">
            <Shield className="h-4 w-4 sm:h-6 sm:w-6 text-purple-400 mx-auto mb-1 sm:mb-2" />
            <div className="text-white font-medium text-xs sm:text-sm">100% Anônimo</div>
            <div className="text-gray-300 text-xs">Totalmente discreto</div>
          </div>
          <div className="bg-white/10 p-2 sm:p-3 rounded-lg text-center">
            <Award className="h-4 w-4 sm:h-6 sm:w-6 text-yellow-400 mx-auto mb-1 sm:mb-2" />
            <div className="text-white font-medium text-xs sm:text-sm">Suporte 24/7</div>
            <div className="text-gray-300 text-xs">Ajuda sempre</div>
          </div>
        </div>

        {/* Social Proof Personalizado */}
        <div className="bg-green-900/30 border border-green-500/30 rounded-lg p-3">
          <div className="flex items-center gap-3">
            <div className="flex -space-x-2">
              <div className="w-6 h-6 sm:w-8 sm:h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full border-2 border-white"></div>
              <div className="w-6 h-6 sm:w-8 sm:h-8 bg-gradient-to-r from-green-500 to-blue-500 rounded-full border-2 border-white"></div>
              <div className="w-6 h-6 sm:w-8 sm:h-8 bg-gradient-to-r from-pink-500 to-red-500 rounded-full border-2 border-white"></div>
              <div className="w-6 h-6 sm:w-8 sm:h-8 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full border-2 border-white flex items-center justify-center text-white text-xs font-bold">
                +{Math.floor(recentPurchases / 1000)}K
              </div>
            </div>
            <div className="flex-1">
              <div className="text-green-300 font-bold text-sm flex items-center gap-1">
                <TrendingUp className="h-4 w-4 animate-pulse" />
                {recentPurchases.toLocaleString()} pessoas com seu perfil já baixaram
              </div>
              <div className="text-green-200 text-xs">⭐ 4.9/5 estrelas • 98.7% recomendam</div>
            </div>
          </div>
        </div>

        {/* CTA Principal Personalizado */}
        <Button
          size="lg"
          onClick={handleCheckoutRedirect}
          className={`w-full bg-gradient-to-r ${personalizedContent.color} hover:opacity-90 text-white font-bold py-4 text-base sm:text-lg rounded-xl shadow-lg transition-all duration-300 hover:scale-105 animate-pulse`}
        >
          <Download className="h-4 w-4 sm:h-5 sm:w-5 mr-2" />
          BAIXAR MINHA SOLUÇÃO - R$ 27,00
        </Button>

        {/* Garantia */}
        <div className="text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Shield className="h-4 w-4 sm:h-5 sm:w-5 text-blue-400" />
            <span className="text-blue-200 font-medium text-sm">Garantia de 7 dias</span>
          </div>
          <p className="text-gray-300 text-xs sm:text-sm">Não satisfeito? Devolvemos 100% do seu dinheiro</p>
        </div>

        {/* Indicadores de Confiança */}
        <div className="flex justify-center items-center gap-4 sm:gap-6 pt-4 border-t border-white/10">
          <div className="text-center">
            <div className="text-green-300 font-bold text-sm">4.9/5</div>
            <div className="text-gray-400 text-xs">Avaliação</div>
          </div>
          <div className="text-center">
            <div className="text-blue-300 font-bold text-sm">45k+</div>
            <div className="text-gray-400 text-xs">Usuários</div>
          </div>
          <div className="text-center">
            <div className="text-purple-300 font-bold text-sm">SSL</div>
            <div className="text-gray-400 text-xs">Seguro</div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
