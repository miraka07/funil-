"use client"

import { useState, useEffect } from "react"
import { TrendingUp, Users, MapPin, Clock } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export function LiveStats() {
  const [stats, setStats] = useState({
    activeUsers: 1247,
    locationsToday: 3891,
    successRate: 98.7,
    avgTime: 2.3,
  })

  useEffect(() => {
    const interval = setInterval(() => {
      setStats((prev) => ({
        activeUsers: prev.activeUsers + Math.floor(Math.random() * 3),
        locationsToday: prev.locationsToday + Math.floor(Math.random() * 2),
        successRate: 98.7 + (Math.random() * 0.6 - 0.3),
        avgTime: 2.3 + (Math.random() * 0.4 - 0.2),
      }))
    }, 3000)

    return () => clearInterval(interval)
  }, [])

  return (
    <Card className="bg-gradient-to-br from-gray-900/50 to-gray-800/30 border-gray-500/30 backdrop-blur-lg">
      <CardContent className="p-4 sm:p-6">
        <h3 className="text-white font-bold text-base sm:text-lg mb-4 text-center">📊 Estatísticas em Tempo Real</h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
          <div className="text-center p-3 bg-white/5 rounded-lg">
            <Users className="h-5 w-5 text-blue-400 mx-auto mb-2" />
            <div className="text-white font-bold text-lg sm:text-xl">{stats.activeUsers.toLocaleString()}</div>
            <div className="text-gray-400 text-xs">Usuários Online</div>
          </div>

          <div className="text-center p-3 bg-white/5 rounded-lg">
            <MapPin className="h-5 w-5 text-red-400 mx-auto mb-2" />
            <div className="text-white font-bold text-lg sm:text-xl">{stats.locationsToday.toLocaleString()}</div>
            <div className="text-gray-400 text-xs">Capturas Hoje</div>
          </div>

          <div className="text-center p-3 bg-white/5 rounded-lg">
            <TrendingUp className="h-5 w-5 text-green-400 mx-auto mb-2" />
            <div className="text-white font-bold text-lg sm:text-xl">{stats.successRate.toFixed(1)}%</div>
            <div className="text-gray-400 text-xs">Taxa Sucesso</div>
          </div>

          <div className="text-center p-3 bg-white/5 rounded-lg">
            <Clock className="h-5 w-5 text-yellow-400 mx-auto mb-2" />
            <div className="text-white font-bold text-lg sm:text-xl">{stats.avgTime.toFixed(1)}s</div>
            <div className="text-gray-400 text-xs">Tempo Médio</div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
