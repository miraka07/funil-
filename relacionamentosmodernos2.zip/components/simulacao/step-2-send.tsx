"use client"

import { useState } from "react"
import { MessageCircle, Zap } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { WhatsAppRealistic } from "./whatsapp-realistic"

interface Props {
  data: {
    customMessage: string
    linkName: string
    redirectUrl: string
    camouflage: string
    previewData: {
      profileName: string
      contentTitle: string
      contentDescription: string
      hashtags: string
      contentType: "video" | "photo" | "story" | "news" | "music" | "post"
    }
  }
  onDone: () => void
}

type SimulationPhase = "ready" | "sending" | "sent" | "delivered" | "read" | "clicked" | "capturing" | "complete"

export function Step2Send({ data, onDone }: Props) {
  const [phase, setPhase] = useState<SimulationPhase>("ready")

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const getPlatformData = () => {
    if (data.redirectUrl.includes("instagram")) {
      return {
        name: "Instagram",
        icon: "📸",
        color: "from-pink-500 to-purple-500",
      }
    } else if (data.redirectUrl.includes("youtube")) {
      return {
        name: "YouTube",
        icon: "🎥",
        color: "from-red-500 to-red-600",
      }
    } else if (data.redirectUrl.includes("tiktok")) {
      return {
        name: "TikTok",
        icon: "🎵",
        color: "from-black to-gray-800",
      }
    } else if (data.redirectUrl.includes("g1.globo.com") || data.redirectUrl.includes("uol.com.br")) {
      return {
        name: "Notícias",
        icon: "📰",
        color: "from-blue-500 to-blue-600",
      }
    } else {
      return {
        name: "Site",
        icon: "🌐",
        color: "from-gray-500 to-gray-600",
      }
    }
  }

  const platformData = getPlatformData()

  const startSimulation = () => {
    setPhase("sending")

    setTimeout(() => setPhase("sent"), 3000)
    setTimeout(() => setPhase("delivered"), 5000)
    setTimeout(() => setPhase("read"), 7000)
    setTimeout(() => setPhase("clicked"), 10000)
    setTimeout(() => setPhase("capturing"), 12000)
    setTimeout(() => setPhase("complete"), 15000)

    setTimeout(() => {
      scrollToTop()
      setTimeout(() => onDone(), 500)
    }, 18000)
  }

  const getPhaseColor = () => {
    switch (phase) {
      case "ready":
        return "text-blue-300"
      case "sending":
      case "sent":
        return "text-yellow-300"
      case "delivered":
      case "read":
        return "text-orange-300"
      case "clicked":
      case "capturing":
        return "text-red-300"
      case "complete":
        return "text-green-300"
      default:
        return "text-white"
    }
  }

  const getStatusText = () => {
    switch (phase) {
      case "ready":
        return "Pronto"
      case "sending":
        return "Enviando"
      case "sent":
        return "Enviado"
      case "delivered":
        return "Entregue"
      case "read":
        return "Lido"
      case "clicked":
        return "Clicado"
      case "capturing":
        return "Capturando"
      case "complete":
        return "Completo"
      default:
        return "Pronto"
    }
  }

  return (
    <Card className="bg-gradient-to-br from-green-900/50 to-green-800/30 border-green-500/30 backdrop-blur-lg">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-3 text-lg sm:text-xl text-white">
          <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center text-sm font-bold">
            2
          </div>
          Demonstração de Envio
          <Badge className={`bg-green-500/20 border-green-500/30 ml-auto text-xs ${getPhaseColor()}`}>
            <MessageCircle className="h-3 w-3 mr-1" />
            {getStatusText()}
          </Badge>
        </CardTitle>
        <p className="text-green-200 text-sm mt-2">Veja como funciona na prática</p>
      </CardHeader>

      <CardContent className="px-4 sm:px-6 space-y-6">
        {/* WhatsApp Simulation */}
        <div className="w-full flex justify-center">
          <div className="w-full max-w-xs">
            <WhatsAppRealistic
              message={data.customMessage}
              linkName={data.linkName}
              linkUrl={data.camouflage}
              phase={phase}
              platformData={platformData}
            />
          </div>
        </div>

        {/* Action Button */}
        {phase === "ready" && (
          <Button
            onClick={startSimulation}
            className="w-full py-3 sm:py-4 text-base sm:text-lg font-bold bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 shadow-xl transform hover:scale-105 transition-all duration-300"
          >
            <Zap className="h-5 w-5 mr-2" />
            Iniciar Demonstração
          </Button>
        )}

        {/* Explicação */}
        <div className="bg-blue-900/30 p-4 rounded-lg border border-blue-500/30">
          <p className="text-blue-200 text-sm text-center">
            <strong>100% Invisível:</strong> A pessoa vai para o {platformData.name} normalmente, sem perceber que a
            localização foi capturada.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
