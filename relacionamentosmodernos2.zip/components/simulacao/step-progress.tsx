"use client"

import { CheckCircle } from "lucide-react"

interface Props {
  current: number
}

export function StepProgress({ current }: Props) {
  const steps = [
    { number: 1, title: "Escolher", description: "Plataforma" },
    { number: 2, title: "Demonstrar", description: "Envio" },
    { number: 3, title: "Capturar", description: "Localização" },
  ]

  return (
    <div className="flex items-center justify-between w-full max-w-md mx-auto">
      {steps.map((step, index) => (
        <div key={step.number} className="flex items-center">
          <div className="flex flex-col items-center">
            <div
              className={`w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center border-2 transition-all duration-300 ${
                current >= step.number
                  ? "bg-green-500 border-green-500 text-white"
                  : "bg-transparent border-gray-400 text-gray-400"
              }`}
            >
              {current > step.number ? (
                <CheckCircle className="h-4 w-4 sm:h-5 sm:w-5" />
              ) : (
                <span className="text-xs sm:text-sm font-bold">{step.number}</span>
              )}
            </div>
            <div className="mt-2 text-center">
              <div
                className={`text-xs sm:text-sm font-medium ${
                  current >= step.number ? "text-green-400" : "text-gray-400"
                }`}
              >
                {step.title}
              </div>
              <div className="text-xs text-gray-500">{step.description}</div>
            </div>
          </div>

          {index < steps.length - 1 && (
            <div
              className={`w-8 sm:w-12 h-0.5 mx-2 sm:mx-4 transition-all duration-300 ${
                current > step.number ? "bg-green-500" : "bg-gray-400"
              }`}
            />
          )}
        </div>
      ))}
    </div>
  )
}
