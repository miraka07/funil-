"use client"

import { useState, useEffect } from "react"
import { Check, CheckCheck } from "lucide-react"

interface Props {
  message: string
  linkName: string
  linkUrl: string
  phase: "ready" | "sending" | "sent" | "delivered" | "read" | "clicked" | "capturing" | "complete"
  platformData: {
    name: string
    icon: string
    color: string
  }
}

export function WhatsAppRealistic({ message, linkName, linkUrl, phase, platformData }: Props) {
  const [showTyping, setShowTyping] = useState(false)
  const [showMessage, setShowMessage] = useState(false)

  useEffect(() => {
    if (phase === "sending") {
      setShowTyping(true)
      setShowMessage(false)
    } else if (phase === "sent") {
      setShowTyping(false)
      setShowMessage(true)
    }
  }, [phase])

  const getMessageStatus = () => {
    switch (phase) {
      case "sent":
        return <Check className="h-4 w-4 text-gray-400" />
      case "delivered":
        return <CheckCheck className="h-4 w-4 text-gray-400" />
      case "read":
      case "clicked":
      case "capturing":
      case "complete":
        return <CheckCheck className="h-4 w-4 text-blue-400" />
      default:
        return null
    }
  }

  const getLinkStatus = () => {
    if (phase === "clicked" || phase === "capturing" || phase === "complete") {
      return "bg-blue-100 border-blue-300"
    }
    return "bg-gray-50 border-gray-200"
  }

  const getPlatformPreview = () => {
    switch (platformData.name) {
      case "Instagram":
        return {
          bgImage: "🖼️ Foto viral",
          description: "Essa foto está viralizando! Mais de 50k curtidas...",
          platformIcon: "📸",
        }
      case "YouTube":
        return {
          bgImage: "▶️ Vídeo",
          description: "Vídeo chocante com milhões de visualizações...",
          platformIcon: "🎥",
        }
      case "TikTok":
        return {
          bgImage: "🎵 Dance",
          description: "Dance viral que todo mundo está fazendo...",
          platformIcon: "🎵",
        }
      case "Notícias":
        return {
          bgImage: "📰 Notícia",
          description: "Notícia urgente que está bombando...",
          platformIcon: "📰",
        }
      default:
        return {
          bgImage: "📱 Conteúdo",
          description: "Conteúdo viral imperdível...",
          platformIcon: "🌐",
        }
    }
  }

  const preview = getPlatformPreview()

  return (
    <div className="bg-[#0a1628] rounded-2xl p-4 max-w-sm mx-auto">
      {/* WhatsApp Header */}
      <div className="flex items-center gap-3 mb-4 pb-3 border-b border-gray-700">
        <div className="w-10 h-10 bg-gray-600 rounded-full flex items-center justify-center">
          <span className="text-white text-sm font-bold">A</span>
        </div>
        <div>
          <div className="text-white font-semibold text-sm">Ana</div>
          <div className="text-gray-400 text-xs">
            {phase === "read" || phase === "clicked" || phase === "capturing" || phase === "complete"
              ? "online"
              : "visto por último hoje às 14:30"}
          </div>
        </div>
      </div>

      {/* Chat Messages */}
      <div className="space-y-3">
        {/* Typing Indicator */}
        {showTyping && (
          <div className="flex justify-start">
            <div className="bg-gray-700 rounded-2xl rounded-bl-md px-4 py-2 max-w-xs">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                <div
                  className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                  style={{ animationDelay: "0.1s" }}
                ></div>
                <div
                  className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                  style={{ animationDelay: "0.2s" }}
                ></div>
              </div>
            </div>
          </div>
        )}

        {/* Message with Link */}
        {showMessage && (
          <div className="flex justify-end">
            <div className="bg-[#005c4b] rounded-2xl rounded-br-md px-4 py-3 max-w-xs">
              <div className="text-white text-sm mb-3">{message}</div>

              {/* Link Preview */}
              <div className={`border rounded-lg p-3 transition-all duration-300 ${getLinkStatus()}`}>
                <div className="flex items-center gap-2 mb-2">
                  <div
                    className={`w-8 h-8 bg-gradient-to-r ${platformData.color} rounded-lg flex items-center justify-center`}
                  >
                    <span className="text-white text-xs font-bold">{preview.platformIcon}</span>
                  </div>
                  <div className="text-xs text-gray-600 font-medium">{platformData.name}</div>
                </div>

                <div className="bg-gray-200 h-24 rounded mb-2 flex items-center justify-center">
                  <span className="text-gray-500 text-xs">{preview.bgImage}</span>
                </div>

                <div className="text-sm font-semibold text-gray-800 mb-1 line-clamp-2">{linkName}</div>

                <div className="text-xs text-gray-600 mb-2">{preview.description}</div>

                <div className="text-xs text-blue-600 font-mono break-all">{linkUrl}</div>
              </div>

              <div className="flex items-center justify-end gap-1 mt-2">
                <span className="text-gray-300 text-xs">14:32</span>
                {getMessageStatus()}
              </div>
            </div>
          </div>
        )}

        {/* Status Messages */}
        {phase === "clicked" && (
          <div className="text-center">
            <div className="text-yellow-400 text-xs bg-yellow-900/30 px-3 py-1 rounded-full inline-block">
              👆 Ana clicou no link
            </div>
          </div>
        )}

        {phase === "capturing" && (
          <div className="text-center">
            <div className="text-red-400 text-xs bg-red-900/30 px-3 py-1 rounded-full inline-block animate-pulse">
              📍 Capturando localização...
            </div>
          </div>
        )}

        {phase === "complete" && (
          <div className="text-center">
            <div className="text-green-400 text-xs bg-green-900/30 px-3 py-1 rounded-full inline-block">
              ✅ Localização capturada!
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
