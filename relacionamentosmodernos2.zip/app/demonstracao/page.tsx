"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  ArrowLeft,
  MessageCircle,
  Shield,
  CheckCircle,
  ExternalLink,
  Users,
  Target,
  Zap,
  Star,
  Sparkles,
} from "lucide-react"
import Link from "next/link"

export default function Demonstracao() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 overflow-x-hidden">
      {/* Header - Agora fixo */}
      <header className="bg-black/20 backdrop-blur-lg border-b border-white/10 fixed top-0 left-0 right-0 z-50">
        <div className="container mx-auto px-3 sm:px-4 py-3 sm:py-4">
          <div className="flex items-center gap-2 sm:gap-3">
            <Link href="/">
              <Button variant="ghost" size="sm" className="p-2 text-white hover:bg-white/10">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 sm:gap-3">
                <div className="w-6 h-6 sm:w-8 sm:h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
                  <Sparkles className="h-3 w-3 sm:h-5 sm:w-5 text-white" />
                </div>
                <div className="min-w-0">
                  <h1 className="text-base sm:text-lg md:text-2xl font-bold text-white truncate">Link Mágico</h1>
                  <p className="text-xs md:text-sm text-purple-200 hidden sm:block">
                    Ferramenta Avançada para Relacionamentos
                  </p>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <Badge className="bg-green-500/20 text-green-300 border-green-500/30 text-xs">
                <div className="w-2 h-2 bg-green-400 rounded-full mr-1 sm:mr-2 animate-pulse"></div>
                Online
              </Badge>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-3 sm:px-4 pt-20 pb-6 sm:pb-8 md:pb-12 max-w-6xl overflow-x-hidden">
        {/* Hero Section */}
        <div className="text-center mb-12 sm:mb-16 relative">
          {/* Background Effects */}
          <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-3xl blur-3xl"></div>

          <div className="relative z-10 px-3">
            <div className="flex justify-center mb-4 sm:mb-6">
              <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 sm:px-6 py-1 sm:py-2 text-xs sm:text-sm font-semibold">
                <Star className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
                Tecnologia Avançada
              </Badge>
            </div>

            <h2 className="text-2xl sm:text-4xl md:text-6xl font-bold text-white mb-6 sm:mb-8 leading-tight">
              Tenha o controle do seu relacionamento{" "}
              <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                sem precisar gerar brigas e estresse
              </span>
            </h2>

            <p className="text-base sm:text-xl md:text-2xl text-gray-300 mb-8 sm:mb-10 leading-relaxed max-w-4xl mx-auto">
              Descubra a verdade sobre seu parceiro(a) de forma discreta e inteligente.
              <br />
              <span className="text-purple-300 font-semibold">Acesse nossa ferramenta completa agora mesmo.</span>
            </p>

            {/* Stats */}
            <div className="flex flex-wrap justify-center gap-4 sm:gap-8 mb-8 sm:mb-10">
              <div className="text-center">
                <div className="text-2xl sm:text-3xl font-bold text-white mb-1">98.7%</div>
                <div className="text-purple-300 text-xs sm:text-sm">Taxa de Sucesso</div>
              </div>
              <div className="text-center">
                <div className="text-2xl sm:text-3xl font-bold text-white mb-1">24/7</div>
                <div className="text-purple-300 text-xs sm:text-sm">Suporte Ativo</div>
              </div>
              <div className="text-center">
                <div className="text-2xl sm:text-3xl font-bold text-white mb-1">15k+</div>
                <div className="text-purple-300 text-xs sm:text-sm">Usuários Ativos</div>
              </div>
            </div>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8 mb-12 sm:mb-16">
          <Card className="bg-gradient-to-br from-blue-900/50 to-blue-800/30 border-blue-500/30 backdrop-blur-lg hover:shadow-2xl hover:shadow-blue-500/20 transition-all duration-500 hover:scale-105 group">
            <CardContent className="p-6 sm:p-8">
              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-2xl flex items-center justify-center mx-auto mb-4 sm:mb-6 group-hover:scale-110 transition-transform duration-300">
                <MessageCircle className="h-6 w-6 sm:h-8 sm:w-8 text-white" />
              </div>
              <h3 className="text-lg sm:text-2xl font-bold text-white mb-3 sm:mb-4 text-center">
                Links com o nome que você quiser colocar
              </h3>
              <p className="text-blue-200 leading-relaxed text-center text-sm sm:text-base">
                Coloque o nome do link para o contexto que você quiser passar
              </p>
              <div className="mt-4 sm:mt-6 flex justify-center">
                <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30 text-xs">Personalização Total</Badge>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-900/50 to-emerald-800/30 border-green-500/30 backdrop-blur-lg hover:shadow-2xl hover:shadow-green-500/20 transition-all duration-500 hover:scale-105 group">
            <CardContent className="p-6 sm:p-8">
              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-r from-green-500 to-emerald-500 rounded-2xl flex items-center justify-center mx-auto mb-4 sm:mb-6 group-hover:scale-110 transition-transform duration-300">
                <CheckCircle className="h-6 w-6 sm:h-8 sm:w-8 text-white" />
              </div>
              <h3 className="text-lg sm:text-2xl font-bold text-white mb-3 sm:mb-4 text-center">Chega de mentiras</h3>
              <p className="text-green-200 leading-relaxed text-center text-sm sm:text-base">
                Não precisa mais se preocupar quando seu parceiro(a) sair
              </p>
              <div className="mt-4 sm:mt-6 flex justify-center">
                <Badge className="bg-green-500/20 text-green-300 border-green-500/30 text-xs">
                  Tranquilidade Total
                </Badge>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-900/50 to-violet-800/30 border-purple-500/30 backdrop-blur-lg hover:shadow-2xl hover:shadow-purple-500/20 transition-all duration-500 hover:scale-105 group">
            <CardContent className="p-6 sm:p-8">
              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-r from-purple-500 to-violet-500 rounded-2xl flex items-center justify-center mx-auto mb-4 sm:mb-6 group-hover:scale-110 transition-transform duration-300">
                <ExternalLink className="h-6 w-6 sm:h-8 sm:w-8 text-white" />
              </div>
              <h3 className="text-lg sm:text-2xl font-bold text-white mb-3 sm:mb-4 text-center">Direcionamento real</h3>
              <p className="text-purple-200 leading-relaxed text-center text-sm sm:text-base">
                Direcione o link para uma página de notícias ou memes do Instagram, zero chances de desconfiar
              </p>
              <div className="mt-4 sm:mt-6 flex justify-center">
                <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30 text-xs">
                  Camuflagem Perfeita
                </Badge>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-pink-900/50 to-rose-800/30 border-pink-500/30 backdrop-blur-lg hover:shadow-2xl hover:shadow-pink-500/20 transition-all duration-500 hover:scale-105 group">
            <CardContent className="p-6 sm:p-8">
              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-r from-pink-500 to-rose-500 rounded-2xl flex items-center justify-center mx-auto mb-4 sm:mb-6 group-hover:scale-110 transition-transform duration-300">
                <Zap className="h-6 w-6 sm:h-8 sm:w-8 text-white" />
              </div>
              <h3 className="text-lg sm:text-2xl font-bold text-white mb-3 sm:mb-4 text-center">
                Acesso ao Link Mágico
              </h3>
              <p className="text-pink-200 leading-relaxed text-center text-sm sm:text-base">
                Ferramenta discreta e eficaz para relacionamentos modernos
              </p>
              <div className="mt-4 sm:mt-6 flex justify-center">
                <Badge className="bg-pink-500/20 text-pink-300 border-pink-500/30 text-xs">Tecnologia Avançada</Badge>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* CTA Section */}
        <div className="text-center space-y-6 sm:space-y-8 relative px-3">
          {/* Background Glow */}
          <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-3xl blur-3xl"></div>

          <Card className="bg-gradient-to-r from-purple-900/80 to-pink-900/80 border-purple-500/30 backdrop-blur-xl shadow-2xl relative z-10">
            <CardContent className="p-8 sm:p-12">
              <div className="flex justify-center mb-4 sm:mb-6">
                <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                  <Sparkles className="h-8 w-8 sm:h-10 sm:w-10 text-white" />
                </div>
              </div>

              <h3 className="text-2xl sm:text-4xl md:text-5xl font-bold text-white mb-4 sm:mb-6">
                Pronto para começar?
              </h3>
              <p className="text-purple-100 mb-8 sm:mb-10 text-base sm:text-xl leading-relaxed max-w-3xl mx-auto">
                Acesse nossa plataforma avançada e tenha controle total sobre seu relacionamento de forma inteligente e
                e sem gerar discussões!
              </p>

              <Link href="/demonstracao/simulacao" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold px-8 sm:px-12 py-4 sm:py-6 text-base sm:text-xl rounded-full shadow-2xl hover:shadow-purple-500/50 transition-all duration-300 transform hover:scale-105 w-full sm:w-auto"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    class="lucide lucide-play h-5 w-5 sm:h-6 sm:w-6 mr-2 sm:mr-3"
                  >
                    <polygon points="6 3 20 12 6 21 6 3"></polygon>
                  </svg>
                  VER DEMONSTRAÇÃO
                </Button>
              </Link>

              <div className="flex flex-wrap justify-center gap-4 sm:gap-8 text-purple-100 mt-8 sm:mt-10">
                <div className="flex items-center gap-2 sm:gap-3">
                  <Shield className="h-4 w-4 sm:h-5 sm:w-5 text-green-400" />
                  <span className="text-sm sm:text-lg">Segurança Garantida</span>
                </div>
                <div className="flex items-center gap-2 sm:gap-3">
                  <Users className="h-4 w-4 sm:h-5 sm:w-5 text-blue-400" />
                  <span className="text-sm sm:text-lg">Acesso Imediato</span>
                </div>
                <div className="flex items-center gap-2 sm:gap-3">
                  <Target className="h-4 w-4 sm:h-5 sm:w-5 text-purple-400" />
                  <span className="text-sm sm:text-lg">Resultados Precisos</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Back to Home */}
          <Link href="/" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
            <Button
              variant="ghost"
              size="lg"
              className="text-white hover:bg-white/10 text-base sm:text-lg px-6 sm:px-8 py-2 sm:py-3"
            >
              <ArrowLeft className="h-4 w-4 sm:h-5 sm:w-5 mr-2" />
              Voltar ao Início
            </Button>
          </Link>
        </div>
      </main>
    </div>
  )
}
