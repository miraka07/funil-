"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ArrowLeft, Settings, MessageCircle, MapPin } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { StepProgress } from "@/components/simulacao/step-progress"
import { Step1Config } from "@/components/simulacao/step-1-config"
import { Step2Send } from "@/components/simulacao/step-2-send"
import { Step3Capture } from "@/components/simulacao/step-3-capture"

export default function Simulacao() {
  const [step, setStep] = useState<1 | 2 | 3>(1)
  const [cfg, setCfg] = useState<any>(null)
  const [capturedCity, setCapturedCity] = useState("")

  // scroll to top on page mount
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }, [])

  // SEMPRE scroll to top quando step muda
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" })
    setTimeout(() => {
      window.scrollTo({ top: 0, behavior: "smooth" })
    }, 100)
  }, [step])

  const handleStep1Done = (data: any) => {
    setCfg(data)
    window.scrollTo({ top: 0, behavior: "smooth" })
    setTimeout(() => {
      setStep(2)
    }, 300)
  }

  const handleStep2Done = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
    setTimeout(() => {
      setStep(3)
    }, 300)
  }

  const handleStep3Done = (city: string) => {
    setCapturedCity(city)
    // Não avança mais para step 4, fica no step 3
  }

  const handleGoBack = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
    setTimeout(() => {
      if (step > 1) {
        setStep((prev) => (prev - 1) as 1 | 2 | 3)
      }
    }, 300)
  }

  const handleEditConfig = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
    setTimeout(() => {
      setStep(1)
    }, 300)
  }

  const getStepIcon = (stepNumber: number) => {
    switch (stepNumber) {
      case 1:
        return Settings
      case 2:
        return MessageCircle
      case 3:
        return MapPin
      default:
        return Settings
    }
  }

  const getStepTitle = (stepNumber: number) => {
    switch (stepNumber) {
      case 1:
        return "Configuração"
      case 2:
        return "Envio WhatsApp"
      case 3:
        return "Resultado"
      default:
        return "Configuração"
    }
  }

  const StepIcon = getStepIcon(step)

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 overflow-x-hidden">
      {/* header fixado */}
      <header className="bg-black/20 backdrop-blur-lg border-b border-white/10 fixed top-0 left-0 right-0 z-50">
        <div className="container mx-auto px-3 sm:px-4 py-3 flex items-center gap-3">
          {step > 1 ? (
            <Button
              variant="outline"
              size="sm"
              onClick={handleGoBack}
              className="p-2 text-white border-white/30 hover:bg-white/10 hover:text-white bg-transparent"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
          ) : (
            <Link href="/demonstracao" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
              <Button
                variant="outline"
                size="sm"
                className="p-2 text-white border-white/30 hover:bg-white/10 hover:text-white bg-transparent"
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
          )}

          <div className="flex items-center gap-2 flex-1 min-w-0">
            <div className="w-7 h-7 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center flex-shrink-0">
              <StepIcon className="h-4 w-4 text-white" />
            </div>
            <div className="min-w-0 flex-1">
              <h1 className="text-white font-bold text-sm sm:text-base truncate">
                Etapa {step}: {getStepTitle(step)}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-shrink-0">
            <Badge className="bg-green-500/20 text-green-300 border-green-500/30 hidden sm:flex text-xs">
              <div className="w-2 h-2 bg-green-400 rounded-full mr-1 animate-pulse"></div>
              Online
            </Badge>
            <div className="text-white text-sm font-medium">{step}/3</div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-3 sm:px-4 pt-20 pb-6 max-w-4xl space-y-4 overflow-x-hidden">
        {/* Step Progress - Apenas 3 etapas */}
        <div className="px-2">
          <StepProgress current={step} />
        </div>

        {/* STEP 1 */}
        {step === 1 && <Step1Config onDone={handleStep1Done} />}

        {/* STEP 2 */}
        {step === 2 && cfg && <Step2Send data={cfg} onDone={handleStep2Done} />}

        {/* STEP 3 */}
        {step === 3 && cfg && <Step3Capture data={cfg} onDone={handleStep3Done} onEdit={handleEditConfig} />}
      </main>
    </div>
  )
}
