"use client"

import { useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  ArrowLeft,
  Clock,
  Eye,
  Share,
  Heart,
  Smartphone,
  TrendingUp,
  Lightbulb,
  Target,
  Shield,
  Zap,
  CheckCircle,
} from "lucide-react"
import Link from "next/link"

export default function ArtigoTecnologiaRelacionamentos() {
  // Scroll para o topo quando a página carregar
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-lg border-b border-white/10 sticky top-0 z-50">
        <div className="container mx-auto px-3 sm:px-4 py-3">
          <div className="flex items-center gap-3">
            <Link href="/" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
              <Button variant="ghost" size="sm" className="p-2 text-white hover:bg-white/10">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div className="flex-1">
              <h1 className="text-white font-bold text-sm sm:text-base">Tech Relacionamentos</h1>
            </div>
            <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30 text-xs">INOVAÇÃO</Badge>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-3 sm:px-4 py-6 max-w-4xl">
        {/* Article Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-4">
            <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30">TECNOLOGIA</Badge>
            <div className="flex items-center gap-1 text-gray-400 text-sm">
              <Clock className="h-4 w-4" />
              <span>Publicado há 6 horas</span>
            </div>
          </div>

          <h1 className="text-white font-black text-2xl sm:text-4xl leading-tight mb-4">
            Tecnologia pode salvar seu relacionamento: como descobrir a verdade sem brigas
          </h1>

          <p className="text-gray-300 text-lg leading-relaxed mb-6">
            Novas ferramentas digitais estão revolucionando a forma como casais lidam com a confiança. Especialistas
            mostram como a tecnologia pode ajudar a reconstruir relacionamentos de forma inteligente e discreta.
          </p>

          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-sm">TR</span>
              </div>
              <div>
                <div className="text-white font-semibold">Tech Relacionamentos</div>
                <div className="text-gray-400 text-sm">Portal especializado em inovação</div>
              </div>
            </div>
            <div className="flex items-center gap-4 text-gray-400">
              <div className="flex items-center gap-1">
                <Eye className="h-4 w-4" />
                <span className="text-sm">2.956</span>
              </div>
              <div className="flex items-center gap-1">
                <Heart className="h-4 w-4" />
                <span className="text-sm">234</span>
              </div>
              <div className="flex items-center gap-1">
                <Share className="h-4 w-4" />
                <span className="text-sm">78</span>
              </div>
            </div>
          </div>
        </div>

        {/* Article Image */}
        <div className="mb-8">
          <div className="aspect-video bg-gradient-to-br from-blue-600/30 to-cyan-600/30 rounded-xl flex items-center justify-center mb-4">
            <div className="text-center">
              <Smartphone className="h-16 w-16 text-white/60 mx-auto mb-4" />
              <h3 className="text-white text-xl font-bold">A Era Digital dos Relacionamentos</h3>
              <p className="text-white/80">Como a tecnologia está mudando o amor</p>
            </div>
          </div>
          <p className="text-gray-400 text-sm text-center">
            Ferramentas digitais modernas oferecem soluções inovadoras para problemas antigos nos relacionamentos
          </p>
        </div>

        {/* Article Content */}
        <div className="prose prose-invert max-w-none">
          <div className="bg-blue-900/30 border-l-4 border-blue-500 p-4 rounded-r-lg mb-6">
            <div className="flex items-center gap-2 mb-2">
              <Lightbulb className="h-5 w-5 text-blue-400" />
              <h3 className="text-blue-300 font-bold text-lg">REVOLUÇÃO DIGITAL</h3>
            </div>
            <p className="text-blue-100 leading-relaxed">
              A mesma tecnologia que muitos culpam por destruir relacionamentos está agora sendo usada para salvá-los.
              <strong>
                Ferramentas inteligentes ajudam casais a reconstruírem a confiança de forma discreta e eficaz.
              </strong>
            </p>
          </div>

          <h2 className="text-white font-bold text-2xl mb-4">A Nova Era dos Relacionamentos</h2>

          <p className="text-gray-300 leading-relaxed mb-4">
            Vivemos em uma época onde a tecnologia permeia todos os aspectos de nossas vidas, incluindo nossos
            relacionamentos.
            <strong>
              Se por um lado ela facilitou a comunicação e aproximou pessoas, por outro criou novos desafios para a
              confiança entre casais.
            </strong>
          </p>

          <p className="text-gray-300 leading-relaxed mb-6">
            Mas uma nova tendência está emergindo: o uso inteligente da tecnologia para fortalecer relacionamentos ao
            invés de destruí-los. Ferramentas modernas estão ajudando milhares de casais a superarem crises de confiança
            de forma madura e responsável.
          </p>

          <div className="bg-gray-900/50 p-6 rounded-xl mb-6">
            <h3 className="text-white font-bold text-xl mb-4">Como a Tecnologia Está Ajudando:</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-400" />
                  <span className="text-gray-300">Verificação discreta de localização</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-400" />
                  <span className="text-gray-300">Esclarecimento de dúvidas sem conflitos</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-400" />
                  <span className="text-gray-300">Reconstrução da confiança mútua</span>
                </div>
              </div>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-400" />
                  <span className="text-gray-300">Prevenção de mal-entendidos</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-400" />
                  <span className="text-gray-300">Transparência nos relacionamentos</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-400" />
                  <span className="text-gray-300">Paz de espírito para ambos</span>
                </div>
              </div>
            </div>
          </div>

          <h2 className="text-white font-bold text-2xl mb-4">O Poder da Transparência Digital</h2>

          <p className="text-gray-300 leading-relaxed mb-4">
            <strong>"A transparência é a base de qualquer relacionamento saudável"</strong>, explica a Dra. Ana Silva,
            terapeuta de casais especializada em relacionamentos modernos. "A tecnologia pode ser uma aliada poderosa
            quando usada com sabedoria e consentimento mútuo."
          </p>

          <p className="text-gray-300 leading-relaxed mb-6">
            Estudos recentes mostram que casais que adotam ferramentas de transparência digital têm
            <strong>85% menos conflitos relacionados à desconfiança</strong> e relatam maior satisfação no
            relacionamento.
          </p>

          <div className="bg-green-900/30 border border-green-500/30 p-4 rounded-lg mb-6">
            <div className="flex items-center gap-2 mb-3">
              <TrendingUp className="h-5 w-5 text-green-400" />
              <h3 className="text-green-300 font-bold">DADOS IMPRESSIONANTES</h3>
            </div>
            <ul className="space-y-2 text-green-100 text-sm">
              <li>
                • <strong>45.000+</strong> casais já usaram ferramentas de transparência digital
              </li>
              <li>
                • <strong>92%</strong> relatam melhoria significativa na confiança
              </li>
              <li>
                • <strong>78%</strong> evitaram separações desnecessárias
              </li>
              <li>
                • <strong>89%</strong> recomendam para outros casais
              </li>
            </ul>
          </div>

          <h2 className="text-white font-bold text-2xl mb-4">Casos de Sucesso Reais</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <Card className="bg-purple-900/30 border-purple-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    J
                  </div>
                  <div>
                    <div className="text-white font-semibold text-sm">Julia & Pedro</div>
                    <div className="text-purple-200 text-xs">Casados há 8 anos</div>
                  </div>
                </div>
                <p className="text-purple-100 text-sm italic">
                  "Passamos por uma crise de confiança terrível. A ferramenta nos ajudou a esclarecer mal-entendidos e
                  reconstruir nossa confiança. Hoje somos mais unidos que nunca."
                </p>
              </CardContent>
            </Card>

            <Card className="bg-cyan-900/30 border-cyan-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-8 h-8 bg-cyan-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    R
                  </div>
                  <div>
                    <div className="text-white font-semibold text-sm">Rafael & Carla</div>
                    <div className="text-cyan-200 text-xs">Namorando há 3 anos</div>
                  </div>
                </div>
                <p className="text-cyan-100 text-sm italic">
                  "Eu viajava muito a trabalho e ela sempre ficava preocupada. Agora ela pode ver onde estou e fica
                  tranquila. Salvou nosso relacionamento."
                </p>
              </CardContent>
            </Card>
          </div>

          {/* CTA Section - Responsivo */}
          <div className="bg-gradient-to-r from-purple-900/80 to-pink-900/80 border border-purple-500/30 rounded-xl p-4 sm:p-6 my-8">
            <div className="text-center">
              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-3 sm:mb-4">
                <Target className="h-6 w-6 sm:h-8 sm:w-8 text-white" />
              </div>
              <h3 className="text-white font-bold text-lg sm:text-2xl mb-2 sm:mb-3 px-2">
                Transforme Seu Relacionamento Hoje
              </h3>
              <p className="text-purple-200 mb-3 sm:mb-4 leading-relaxed text-sm sm:text-base px-2">
                Não deixe a desconfiança destruir o que vocês construíram juntos. Descubra como milhares de casais estão
                usando a tecnologia para fortalecer seus relacionamentos.
              </p>

              <div className="bg-blue-900/30 border border-blue-500/30 rounded-lg p-3 sm:p-4 mb-3 sm:mb-4">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Shield className="h-4 w-4 sm:h-5 sm:w-5 text-blue-400" />
                  <span className="text-blue-300 font-bold text-sm sm:text-base">100% Seguro e Discreto</span>
                </div>
                <p className="text-blue-200 text-xs sm:text-sm px-2">
                  Ferramenta aprovada por terapeutas de casal e especialistas em relacionamentos
                </p>
              </div>

              <Link href="/demonstracao" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
                <Button
                  size="lg"
                  className="w-full sm:w-auto bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold px-4 sm:px-8 py-3 sm:py-4 text-sm sm:text-lg rounded-full shadow-xl hover:shadow-purple-500/50 transition-all duration-300 transform hover:scale-105 mb-3 sm:mb-4"
                >
                  <Zap className="h-4 w-4 sm:h-5 sm:w-5 mr-2" />
                  <span className="truncate">Experimentar Gratuitamente</span>
                </Button>
              </Link>

              <p className="text-gray-400 text-xs sm:text-sm px-2">
                ⭐ Avaliação 4.9/5 • Mais de 45k casais satisfeitos
              </p>
            </div>
          </div>

          <h2 className="text-white font-bold text-2xl mb-4">O Futuro dos Relacionamentos</h2>

          <p className="text-gray-300 leading-relaxed mb-4">
            Estamos entrando em uma nova era onde a tecnologia e os relacionamentos humanos se complementam de forma
            harmoniosa.
            <strong>
              As ferramentas digitais não substituem a comunicação e o diálogo, mas podem ser catalisadores para
              conversas importantes.
            </strong>
          </p>

          <p className="text-gray-300 leading-relaxed mb-6">
            "O segredo está em usar a tecnologia como uma ponte para a transparência, não como uma arma de vigilância",
            conclui a Dra. Ana Silva.{" "}
            <strong>
              "Quando ambos os parceiros concordam em ser transparentes, a confiança se fortalece naturalmente."
            </strong>
          </p>

          <div className="bg-yellow-900/30 border border-yellow-500/30 p-4 rounded-lg mb-6">
            <div className="flex items-center gap-2 mb-2">
              <Lightbulb className="h-5 w-5 text-yellow-400" />
              <h3 className="text-yellow-300 font-bold">DICA DOS ESPECIALISTAS</h3>
            </div>
            <p className="text-yellow-100 text-sm leading-relaxed">
              A chave para usar a tecnologia nos relacionamentos é a <strong>transparência mútua</strong>. Quando ambos
              os parceiros concordam em compartilhar informações, a ferramenta se torna um instrumento de fortalecimento
              da confiança, não de vigilância.
            </p>
          </div>

          <h2 className="text-white font-bold text-2xl mb-4">Conclusão</h2>

          <p className="text-gray-300 leading-relaxed mb-6">
            A tecnologia veio para ficar, e cabe a nós decidirmos como usá-la em nossos relacionamentos.
            <strong>
              Quando usada com sabedoria, transparência e consentimento mútuo, ela pode ser uma poderosa aliada na
              construção de relacionamentos mais sólidos e confiáveis.
            </strong>
          </p>

          {/* Final CTA - Responsivo */}
          <div className="bg-gradient-to-r from-blue-600/80 to-cyan-600/80 border border-blue-400/50 rounded-lg p-3 sm:p-4 text-center">
            <h4 className="text-white font-black text-base sm:text-xl mb-2 px-2">
              💡 Seja Parte da Revolução dos Relacionamentos
            </h4>
            <p className="text-blue-100 text-xs sm:text-sm mb-3 leading-relaxed px-2">
              Junte-se aos milhares de casais que já descobriram como a tecnologia pode fortalecer ao invés de destruir
              relacionamentos.
            </p>
            <Link href="/demonstracao" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
              <Button
                size="lg"
                className="w-full sm:w-auto bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold px-4 sm:px-6 py-2 sm:py-3 text-sm sm:text-base rounded-full"
              >
                <span className="truncate">Começar Agora Gratuitamente</span>
              </Button>
            </Link>
          </div>
        </div>
      </main>
    </div>
  )
}
