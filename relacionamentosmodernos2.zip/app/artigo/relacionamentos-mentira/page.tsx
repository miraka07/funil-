"use client"

import { useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Clock, Eye, Share, Heart, TrendingUp, AlertTriangle, Target, Shield, Zap } from "lucide-react"
import Link from "next/link"

export default function ArtigoRelacionamentosMentira() {
  // Scroll para o topo quando a página carregar
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-lg border-b border-white/10 sticky top-0 z-50">
        <div className="container mx-auto px-3 sm:px-4 py-3">
          <div className="flex items-center gap-3">
            <Link href="/" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
              <Button variant="ghost" size="sm" className="p-2 text-white hover:bg-white/10">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div className="flex-1">
              <h1 className="text-white font-bold text-sm sm:text-base">Portal de Relacionamentos</h1>
            </div>
            <Badge className="bg-red-500/20 text-red-300 border-red-500/30 text-xs">TRENDING</Badge>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-3 sm:px-4 py-6 max-w-4xl">
        {/* Article Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-4">
            <Badge className="bg-red-500/20 text-red-300 border-red-500/30">RELACIONAMENTOS</Badge>
            <div className="flex items-center gap-1 text-gray-400 text-sm">
              <Clock className="h-4 w-4" />
              <span>Publicado há 2 horas</span>
            </div>
          </div>

          <h1 className="text-white font-black text-2xl sm:text-4xl leading-tight mb-4">
            Como a mentira acaba com relacionamentos: 73% dos casais se separam por falta de confiança
          </h1>

          <p className="text-gray-300 text-lg leading-relaxed mb-6">
            Pesquisa exclusiva revela que a desconfiança é o principal motivo de término de relacionamentos no Brasil.
            Especialistas alertam sobre os sinais e apresentam soluções modernas para reconstruir a confiança.
          </p>

          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-sm">DS</span>
              </div>
              <div>
                <div className="text-white font-semibold">Dr. Marina Santos</div>
                <div className="text-gray-400 text-sm">Psicóloga especialista em relacionamentos</div>
              </div>
            </div>
            <div className="flex items-center gap-4 text-gray-400">
              <div className="flex items-center gap-1">
                <Eye className="h-4 w-4" />
                <span className="text-sm">2.847</span>
              </div>
              <div className="flex items-center gap-1">
                <Heart className="h-4 w-4" />
                <span className="text-sm">189</span>
              </div>
              <div className="flex items-center gap-1">
                <Share className="h-4 w-4" />
                <span className="text-sm">67</span>
              </div>
            </div>
          </div>
        </div>

        {/* Article Image */}
        <div className="mb-8">
          <div className="aspect-video bg-gradient-to-br from-red-600/30 to-pink-600/30 rounded-xl flex items-center justify-center mb-4">
            <div className="text-center">
              <AlertTriangle className="h-16 w-16 text-white/60 mx-auto mb-4" />
              <h3 className="text-white text-xl font-bold">A Crise da Confiança nos Relacionamentos</h3>
              <p className="text-white/80">Dados alarmantes sobre infidelidade no Brasil</p>
            </div>
          </div>
          <p className="text-gray-400 text-sm text-center">
            Imagem ilustrativa: Pesquisa revela dados preocupantes sobre confiança em relacionamentos
          </p>
        </div>

        {/* Article Content */}
        <div className="prose prose-invert max-w-none">
          <div className="bg-red-900/30 border-l-4 border-red-500 p-4 rounded-r-lg mb-6">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="h-5 w-5 text-red-400" />
              <h3 className="text-red-300 font-bold text-lg">DADOS ALARMANTES</h3>
            </div>
            <p className="text-red-100 leading-relaxed">
              Uma pesquisa realizada com mais de 10.000 brasileiros revelou que{" "}
              <strong>73% dos relacionamentos terminam por falta de confiança</strong>. O estudo, conduzido pelo
              Instituto de Pesquisas Comportamentais, mostra que a desconfiança é hoje o maior inimigo dos casais
              modernos.
            </p>
          </div>

          <h2 className="text-white font-bold text-2xl mb-4">Os Números Não Mentem</h2>

          <p className="text-gray-300 leading-relaxed mb-4">
            Segundo a Dra. Marina Santos, psicóloga especialista em relacionamentos com mais de 15 anos de experiência,
            os dados são preocupantes:{" "}
            <strong>
              "Nunca vi tantos casais chegarem ao meu consultório com problemas de confiança. A tecnologia facilitou
              tanto a comunicação quanto a traição"
            </strong>
            .
          </p>

          <div className="bg-gray-900/50 p-6 rounded-xl mb-6">
            <h3 className="text-white font-bold text-xl mb-4">Principais Causas de Desconfiança:</h3>
            <ul className="space-y-3 text-gray-300">
              <li className="flex items-center gap-3">
                <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                <span>
                  <strong>Mentiras sobre localização</strong> - 45% dos casos
                </span>
              </li>
              <li className="flex items-center gap-3">
                <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                <span>
                  <strong>Comportamento suspeito no celular</strong> - 38% dos casos
                </span>
              </li>
              <li className="flex items-center gap-3">
                <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                <span>
                  <strong>Mudanças repentinas de rotina</strong> - 32% dos casos
                </span>
              </li>
              <li className="flex items-center gap-3">
                <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                <span>
                  <strong>Histórico de traições anteriores</strong> - 28% dos casos
                </span>
              </li>
            </ul>
          </div>

          <h2 className="text-white font-bold text-2xl mb-4">O Que Dizem os Especialistas</h2>

          <p className="text-gray-300 leading-relaxed mb-4">
            "A desconfiança é como um câncer no relacionamento", explica a Dra. Marina.
            <strong>
              "Ela corrói aos poucos a base de qualquer união. O problema é que muitas vezes a pessoa tem razão em
              desconfiar, mas não consegue provar nada"
            </strong>
            .
          </p>

          <p className="text-gray-300 leading-relaxed mb-6">
            O estudo também revelou que <strong>80% das pessoas que desconfiam do parceiro estão certas</strong>. Isso
            significa que nossa intuição raramente nos engana, mas a falta de provas concretas gera ainda mais ansiedade
            e conflitos.
          </p>

          <div className="bg-yellow-900/30 border border-yellow-500/30 p-4 rounded-lg mb-6">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="h-5 w-5 text-yellow-400" />
              <h3 className="text-yellow-300 font-bold">ATENÇÃO: Sinais de Alerta</h3>
            </div>
            <p className="text-yellow-100 text-sm leading-relaxed">
              Se você reconhece estes sinais no seu relacionamento, pode ser hora de buscar a verdade: mudanças no
              comportamento, mentiras sobre onde estava, celular sempre virado para baixo, defensividade excessiva
              quando questionado sobre atividades.
            </p>
          </div>

          <h2 className="text-white font-bold text-2xl mb-4">A Solução Está na Tecnologia</h2>

          <p className="text-gray-300 leading-relaxed mb-4">
            Paradoxalmente, a mesma tecnologia que facilita a infidelidade também pode ser a solução para reconstruir a
            confiança.
            <strong>
              "Hoje existem ferramentas discretas e legais que permitem aos casais esclarecerem dúvidas sem gerar
              conflitos desnecessários"
            </strong>
            , afirma a especialista.
          </p>

          <p className="text-gray-300 leading-relaxed mb-6">
            Ferramentas modernas de localização, quando usadas com transparência e consentimento mútuo, têm ajudado
            milhares de casais a reconstruírem a confiança perdida.
            <strong>"É melhor saber a verdade, seja ela qual for, do que viver na incerteza constante"</strong>.
          </p>

          {/* CTA Section - Responsivo */}
          <div className="bg-gradient-to-r from-purple-900/80 to-pink-900/80 border border-purple-500/30 rounded-xl p-4 sm:p-6 my-8">
            <div className="text-center">
              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-3 sm:mb-4">
                <Target className="h-6 w-6 sm:h-8 sm:w-8 text-white" />
              </div>
              <h3 className="text-white font-bold text-lg sm:text-2xl mb-2 sm:mb-3 px-2">
                Descubra a Verdade Sobre Seu Relacionamento
              </h3>
              <p className="text-purple-200 mb-3 sm:mb-4 leading-relaxed text-sm sm:text-base px-2">
                Não deixe a dúvida destruir seu relacionamento. Milhares de pessoas já descobriram a verdade e
                conseguiram tomar as decisões certas para suas vidas.
              </p>

              <div className="bg-green-900/30 border border-green-500/30 rounded-lg p-3 sm:p-4 mb-3 sm:mb-4">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Shield className="h-4 w-4 sm:h-5 sm:w-5 text-green-400" />
                  <span className="text-green-300 font-bold text-sm sm:text-base">100% Discreto e Seguro</span>
                </div>
                <p className="text-green-200 text-xs sm:text-sm px-2">
                  Ferramenta utilizada por mais de 45.000 pessoas para esclarecer dúvidas em relacionamentos
                </p>
              </div>

              <Link href="/demonstracao" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
                <Button
                  size="lg"
                  className="w-full sm:w-auto bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold px-4 sm:px-8 py-3 sm:py-4 text-sm sm:text-lg rounded-full shadow-xl hover:shadow-purple-500/50 transition-all duration-300 transform hover:scale-105 mb-3 sm:mb-4"
                >
                  <Zap className="h-4 w-4 sm:h-5 sm:w-5 mr-2" />
                  <span className="truncate">Testar Ferramenta Gratuitamente</span>
                </Button>
              </Link>

              <p className="text-gray-400 text-xs sm:text-sm px-2">
                ⭐ Avaliação 4.9/5 • Mais de 45k usuários satisfeitos
              </p>
            </div>
          </div>

          <h2 className="text-white font-bold text-2xl mb-4">Casos Reais de Sucesso</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <Card className="bg-blue-900/30 border-blue-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    A
                  </div>
                  <div>
                    <div className="text-white font-semibold text-sm">Ana, 32 anos</div>
                    <div className="text-blue-200 text-xs">São Paulo, SP</div>
                  </div>
                </div>
                <p className="text-blue-100 text-sm italic">
                  "Descobri que meu marido estava mentindo sobre onde passava as noites. A ferramenta me deu a prova que
                  eu precisava para confrontá-lo. Hoje estamos em terapia de casal e reconstruindo nossa confiança."
                </p>
              </CardContent>
            </Card>

            <Card className="bg-green-900/30 border-green-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    R
                  </div>
                  <div>
                    <div className="text-white font-semibold text-sm">Roberto, 28 anos</div>
                    <div className="text-green-200 text-xs">Rio de Janeiro, RJ</div>
                  </div>
                </div>
                <p className="text-green-100 text-sm italic">
                  "Minha namorada sempre desconfiava de mim sem motivo. Usei a ferramenta para provar onde eu realmente
                  estava durante uma viagem de trabalho. Isso salvou nosso relacionamento."
                </p>
              </CardContent>
            </Card>
          </div>

          <h2 className="text-white font-bold text-2xl mb-4">Conclusão</h2>

          <p className="text-gray-300 leading-relaxed mb-4">
            A confiança é o pilar fundamental de qualquer relacionamento saudável. Quando ela é abalada, é preciso agir
            rapidamente para evitar que pequenas dúvidas se transformem em grandes problemas.
          </p>

          <p className="text-gray-300 leading-relaxed mb-6">
            <strong>
              Lembre-se: é melhor saber a verdade, por mais dolorosa que seja, do que viver na incerteza constante.
            </strong>
            A tecnologia moderna oferece ferramentas discretas e eficazes para esclarecer dúvidas e, quem sabe, salvar
            relacionamentos que ainda têm conserto.
          </p>

          {/* Final CTA - Responsivo */}
          <div className="bg-gradient-to-r from-red-600/80 to-orange-600/80 border border-red-400/50 rounded-lg p-3 sm:p-4 text-center">
            <h4 className="text-white font-black text-base sm:text-xl mb-2 px-2">
              🚨 Não Deixe a Dúvida Destruir Seu Relacionamento
            </h4>
            <p className="text-red-100 text-xs sm:text-sm mb-3 leading-relaxed px-2">
              Milhares de pessoas já descobriram a verdade e tomaram as decisões certas para suas vidas. Não seja mais
              uma vítima da incerteza.
            </p>
            <Link href="/demonstracao" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
              <Button
                size="lg"
                className="w-full sm:w-auto bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold px-4 sm:px-6 py-2 sm:py-3 text-sm sm:text-base rounded-full"
              >
                <span className="truncate">Descobrir a Verdade Agora</span>
              </Button>
            </Link>
          </div>
        </div>
      </main>
    </div>
  )
}
