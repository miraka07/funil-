"use client"

import { useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  ArrowLeft,
  Clock,
  Eye,
  Share,
  Heart,
  MapPin,
  TrendingUp,
  AlertTriangle,
  Target,
  Zap,
  Users,
} from "lucide-react"
import Link from "next/link"

export default function ArtigoTraicaoLocalizacao() {
  // Scroll para o topo quando a página carregar
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-orange-900 to-slate-900">
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-lg border-b border-white/10 sticky top-0 z-50">
        <div className="container mx-auto px-3 sm:px-4 py-3">
          <div className="flex items-center gap-3">
            <Link href="/" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
              <Button variant="ghost" size="sm" className="p-2 text-white hover:bg-white/10">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div className="flex-1">
              <h1 className="text-white font-bold text-sm sm:text-base">Portal de Psicologia</h1>
            </div>
            <Badge className="bg-orange-500/20 text-orange-300 border-orange-500/30 text-xs">EXCLUSIVO</Badge>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-3 sm:px-4 py-6 max-w-4xl">
        {/* Article Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-4">
            <Badge className="bg-orange-500/20 text-orange-300 border-orange-500/30">PSICOLOGIA</Badge>
            <div className="flex items-center gap-1 text-gray-400 text-sm">
              <Clock className="h-4 w-4" />
              <span>Publicado há 4 horas</span>
            </div>
          </div>

          <h1 className="text-white font-black text-2xl sm:text-4xl leading-tight mb-4">
            80% dos parceiros mentem sobre onde estão quando vão trair, revela estudo
          </h1>

          <p className="text-gray-300 text-lg leading-relaxed mb-6">
            Investigação inédita com mais de 10 mil pessoas mostra os padrões de comportamento mais comuns em casos de
            infidelidade. Especialistas revelam como identificar mentiras sobre localização e o que fazer quando a
            desconfiança surge.
          </p>

          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-orange-500 to-red-500 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-sm">CM</span>
              </div>
              <div>
                <div className="text-white font-semibold">Prof. Carlos Mendes</div>
                <div className="text-gray-400 text-sm">Psicólogo comportamental - USP</div>
              </div>
            </div>
            <div className="flex items-center gap-4 text-gray-400">
              <div className="flex items-center gap-1">
                <Eye className="h-4 w-4" />
                <span className="text-sm">4.231</span>
              </div>
              <div className="flex items-center gap-1">
                <Heart className="h-4 w-4" />
                <span className="text-sm">312</span>
              </div>
              <div className="flex items-center gap-1">
                <Share className="h-4 w-4" />
                <span className="text-sm">89</span>
              </div>
            </div>
          </div>
        </div>

        {/* Article Image */}
        <div className="mb-8">
          <div className="aspect-video bg-gradient-to-br from-orange-600/30 to-red-600/30 rounded-xl flex items-center justify-center mb-4">
            <div className="text-center">
              <MapPin className="h-16 w-16 text-white/60 mx-auto mb-4" />
              <h3 className="text-white text-xl font-bold">O Mapa da Traição</h3>
              <p className="text-white/80">Como a localização revela infidelidade</p>
            </div>
          </div>
          <p className="text-gray-400 text-sm text-center">
            Estudo revela padrões comportamentais de pessoas infiéis em relação à localização
          </p>
        </div>

        {/* Article Content */}
        <div className="prose prose-invert max-w-none">
          <div className="bg-orange-900/30 border-l-4 border-orange-500 p-4 rounded-r-lg mb-6">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="h-5 w-5 text-orange-400" />
              <h3 className="text-orange-300 font-bold text-lg">DESCOBERTA CHOCANTE</h3>
            </div>
            <p className="text-orange-100 leading-relaxed">
              Um estudo revolucionário conduzido pela Universidade de São Paulo analisou o comportamento de mais de
              10.000 pessoas e descobriu que{" "}
              <strong>80% dos infiéis mentem sistematicamente sobre sua localização</strong> durante episódios de
              traição.
            </p>
          </div>

          <h2 className="text-white font-bold text-2xl mb-4">A Pesquisa Que Mudou Tudo</h2>

          <p className="text-gray-300 leading-relaxed mb-4">
            O Prof. Carlos Mendes, coordenador da pesquisa, explica:{" "}
            <strong>
              "Descobrimos que a mentira sobre localização é o primeiro e mais comum sinal de infidelidade. É quase um
              padrão universal entre pessoas que traem"
            </strong>
            .
          </p>

          <p className="text-gray-300 leading-relaxed mb-6">
            O estudo, que durou 3 anos e envolveu participantes de todas as regiões do Brasil, revelou dados
            surpreendentes sobre os padrões comportamentais de pessoas infiéis.
          </p>

          <div className="bg-gray-900/50 p-6 rounded-xl mb-6">
            <h3 className="text-white font-bold text-xl mb-4">Principais Descobertas do Estudo:</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    80%
                  </div>
                  <span className="text-gray-300">Mentem sobre localização</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    67%
                  </div>
                  <span className="text-gray-300">Criam álibis falsos</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    54%
                  </div>
                  <span className="text-gray-300">Usam "trabalho" como desculpa</span>
                </div>
              </div>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    43%
                  </div>
                  <span className="text-gray-300">Inventam compromissos familiares</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    38%
                  </div>
                  <span className="text-gray-300">Desligam localização do celular</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    29%
                  </div>
                  <span className="text-gray-300">Pedem para amigos mentirem</span>
                </div>
              </div>
            </div>
          </div>

          <h2 className="text-white font-bold text-2xl mb-4">Os Sinais Que Não Mentem</h2>

          <p className="text-gray-300 leading-relaxed mb-4">
            Segundo o estudo, existem padrões comportamentais claros que indicam quando alguém está mentindo sobre sua
            localização.
            <strong>"A inconsistência nas histórias é o maior indicador"</strong>, afirma o Prof. Mendes.
          </p>

          <div className="bg-red-900/30 border border-red-500/30 p-4 rounded-lg mb-6">
            <div className="flex items-center gap-2 mb-3">
              <AlertTriangle className="h-5 w-5 text-red-400" />
              <h3 className="text-red-300 font-bold">SINAIS DE ALERTA</h3>
            </div>
            <ul className="space-y-2 text-red-100 text-sm">
              <li>• Histórias que mudam quando questionadas novamente</li>
              <li>• Demora excessiva para responder mensagens sobre localização</li>
              <li>• Desculpas muito elaboradas ou detalhadas demais</li>
              <li>• Evita compartilhar localização em tempo real</li>
              <li>• Fica defensivo quando questionado sobre onde estava</li>
              <li>• Celular sempre no silencioso ou virado para baixo</li>
            </ul>
          </div>

          <h2 className="text-white font-bold text-2xl mb-4">O Impacto Psicológico da Desconfiança</h2>

          <p className="text-gray-300 leading-relaxed mb-4">
            <strong>"A desconfiança constante é devastadora para a saúde mental"</strong>, explica o pesquisador.
            "Pessoas que vivem suspeitando do parceiro desenvolvem ansiedade, depressão e até síndrome do pânico."
          </p>

          <p className="text-gray-300 leading-relaxed mb-6">
            O estudo mostrou que <strong>92% das pessoas que desconfiam do parceiro têm razão</strong>. Isso significa
            que nossa intuição raramente nos engana, mas a falta de provas concretas gera um ciclo vicioso de ansiedade
            e conflitos.
          </p>

          {/* CTA Section - Responsivo */}
          <div className="bg-gradient-to-r from-purple-900/80 to-pink-900/80 border border-purple-500/30 rounded-xl p-4 sm:p-6 my-8">
            <div className="text-center">
              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-3 sm:mb-4">
                <Target className="h-6 w-6 sm:h-8 sm:w-8 text-white" />
              </div>
              <h3 className="text-white font-bold text-lg sm:text-2xl mb-2 sm:mb-3 px-2">Pare de Viver na Incerteza</h3>
              <p className="text-purple-200 mb-3 sm:mb-4 leading-relaxed text-sm sm:text-base px-2">
                Se você reconhece estes sinais no seu relacionamento, não precisa mais viver na dúvida. Existe uma forma
                discreta e segura de descobrir a verdade.
              </p>

              <div className="bg-green-900/30 border border-green-500/30 rounded-lg p-3 sm:p-4 mb-3 sm:mb-4">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Users className="h-4 w-4 sm:h-5 sm:w-5 text-green-400" />
                  <span className="text-green-300 font-bold text-sm sm:text-base">
                    Mais de 45.000 pessoas já descobriram a verdade
                  </span>
                </div>
                <p className="text-green-200 text-xs sm:text-sm px-2">
                  Ferramenta 100% discreta utilizada por milhares de brasileiros
                </p>
              </div>

              <Link href="/demonstracao" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
                <Button
                  size="lg"
                  className="w-full sm:w-auto bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold px-4 sm:px-8 py-3 sm:py-4 text-sm sm:text-lg rounded-full shadow-xl hover:shadow-purple-500/50 transition-all duration-300 transform hover:scale-105 mb-3 sm:mb-4"
                >
                  <Zap className="h-4 w-4 sm:h-5 sm:w-5 mr-2" />
                  <span className="truncate">Descobrir a Verdade Agora</span>
                </Button>
              </Link>

              <p className="text-gray-400 text-xs sm:text-sm px-2">
                ⭐ Avaliação 4.9/5 • Resultados em menos de 5 minutos
              </p>
            </div>
          </div>

          <h2 className="text-white font-bold text-2xl mb-4">Depoimentos Reais</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <Card className="bg-blue-900/30 border-blue-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    L
                  </div>
                  <div>
                    <div className="text-white font-semibold text-sm">Luciana, 29 anos</div>
                    <div className="text-blue-200 text-xs">Belo Horizonte, MG</div>
                  </div>
                </div>
                <p className="text-blue-100 text-sm italic">
                  "Meu marido sempre dizia que estava no trabalho até tarde, mas algo não batia. Descobri que ele estava
                  em outro lugar completamente diferente. A verdade doeu, mas me libertou."
                </p>
              </CardContent>
            </Card>

            <Card className="bg-green-900/30 border-green-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    M
                  </div>
                  <div>
                    <div className="text-white font-semibold text-sm">Marcos, 35 anos</div>
                    <div className="text-green-200 text-xs">Curitiba, PR</div>
                  </div>
                </div>
                <p className="text-green-100 text-sm italic">
                  "Minha esposa desconfiava de mim sem motivo. Usei a ferramenta para provar que eu estava realmente
                  onde dizia estar. Salvou nosso casamento."
                </p>
              </CardContent>
            </Card>
          </div>

          <h2 className="text-white font-bold text-2xl mb-4">A Solução Moderna</h2>

          <p className="text-gray-300 leading-relaxed mb-4">
            <strong>"A tecnologia que facilita a traição também pode ser usada para descobrir a verdade"</strong>,
            conclui o Prof. Mendes. "O importante é usar essas ferramentas de forma ética e responsável."
          </p>

          <p className="text-gray-300 leading-relaxed mb-6">
            Ferramentas modernas de verificação de localização têm ajudado milhares de pessoas a esclarecerem dúvidas e
            tomarem decisões importantes sobre seus relacionamentos.
            <strong>É melhor saber a verdade do que viver na incerteza constante.</strong>
          </p>

          {/* Final CTA - Responsivo */}
          <div className="bg-gradient-to-r from-red-600/80 to-orange-600/80 border border-red-400/50 rounded-lg p-3 sm:p-4 text-center">
            <h4 className="text-white font-black text-base sm:text-xl mb-2 px-2">
              🚨 Sua Intuição Está Certa em 92% dos Casos
            </h4>
            <p className="text-red-100 text-xs sm:text-sm mb-3 leading-relaxed px-2">
              Não ignore os sinais. Milhares de pessoas já descobriram a verdade e puderam tomar as decisões certas para
              suas vidas.
            </p>
            <Link href="/demonstracao" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
              <Button
                size="lg"
                className="w-full sm:w-auto bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold px-4 sm:px-6 py-2 sm:py-3 text-sm sm:text-base rounded-full"
              >
                <span className="truncate">Testar Ferramenta Gratuitamente</span>
              </Button>
            </Link>
          </div>
        </div>
      </main>
    </div>
  )
}
