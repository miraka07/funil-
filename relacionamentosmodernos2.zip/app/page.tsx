"use client"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Clock, Eye, Heart, Shield, TrendingUp, Users, Sparkles, Star, Target } from "lucide-react"
import Link from "next/link"

export default function Component() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 overflow-x-hidden">
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-lg border-b border-white/10">
        <div className="container mx-auto px-3 sm:px-4 py-4 sm:py-6">
          <div className="text-center max-w-6xl mx-auto">
            <div className="flex justify-center items-center gap-2 sm:gap-3 mb-3 sm:mb-4">
              <div className="w-8 h-8 sm:w-10 sm:h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                <Sparkles className="h-4 w-4 sm:h-6 sm:w-6 text-white" />
              </div>
              <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-3 sm:px-4 py-1 text-xs sm:text-sm">
                <Star className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
                Plataforma Avançada
              </Badge>
            </div>
            <h1 className="text-2xl sm:text-4xl lg:text-6xl font-bold text-white mb-3 sm:mb-4 leading-tight px-2">
              A Verdade Sobre Relacionamentos Modernos
            </h1>
            <p className="text-base sm:text-xl lg:text-2xl text-gray-300 leading-relaxed max-w-4xl mx-auto px-3">
              Descubra como a tecnologia está mudando a forma como lidamos com a confiança nos relacionamentos
            </p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-3 sm:px-4 py-6 sm:py-8 lg:py-12 max-w-7xl overflow-x-hidden">
        {/* Últimas Notícias */}
        <section className="mb-12 sm:mb-16">
          <div className="flex items-center justify-center gap-2 sm:gap-3 mb-6 sm:mb-8">
            <TrendingUp className="h-5 w-5 sm:h-6 sm:w-6 text-red-400" />
            <h2 className="text-xl sm:text-3xl lg:text-4xl font-bold text-white text-center">ÚLTIMAS NOTÍCIAS</h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
            {/* Notícia 1 */}
            <Link
              href="/artigo/relacionamentos-mentira"
              className="cursor-pointer hover:scale-105 transition-transform"
            >
              <Card className="bg-gradient-to-br from-red-900/50 to-red-800/30 border-red-500/30 backdrop-blur-lg hover:shadow-2xl hover:shadow-red-500/20 transition-all duration-500">
                <CardHeader className="pb-3 sm:pb-4 p-4 sm:p-6">
                  <div className="flex items-center gap-2 text-xs sm:text-sm text-red-200 mb-2 sm:mb-3">
                    <Badge className="bg-red-500/20 text-red-300 border-red-500/30 text-xs">Relacionamentos</Badge>
                    <div className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      <span>2 horas atrás</span>
                    </div>
                  </div>
                  <CardTitle className="text-base sm:text-lg lg:text-xl leading-tight text-white">
                    Como a mentira acaba com relacionamentos: 73% dos casais se separam por falta de confiança
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 sm:p-6 pt-0">
                  <CardDescription className="mb-3 sm:mb-4 text-red-100 leading-relaxed text-sm">
                    Pesquisa revela que a desconfiança é o principal motivo de término de relacionamentos no Brasil.
                    Especialistas alertam sobre os sinais.
                  </CardDescription>
                  <div className="flex items-center justify-between text-xs sm:text-sm text-red-200">
                    <span>Por Dr. Marina Santos</span>
                    <div className="flex items-center gap-1">
                      <Eye className="h-3 w-3" />
                      <span>2.8k</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>

            {/* Notícia 2 */}
            <Link href="/artigo/traicao-localizacao" className="cursor-pointer hover:scale-105 transition-transform">
              <Card className="bg-gradient-to-br from-orange-900/50 to-orange-800/30 border-orange-500/30 backdrop-blur-lg hover:shadow-2xl hover:shadow-orange-500/20 transition-all duration-500">
                <CardHeader className="pb-3 sm:pb-4 p-4 sm:p-6">
                  <div className="flex items-center gap-2 text-xs sm:text-sm text-orange-200 mb-2 sm:mb-3">
                    <Badge className="bg-orange-500/20 text-orange-300 border-orange-500/30 text-xs">Psicologia</Badge>
                    <div className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      <span>4 horas atrás</span>
                    </div>
                  </div>
                  <CardTitle className="text-base sm:text-lg lg:text-xl leading-tight text-white">
                    80% dos parceiros mentem sobre onde estão quando vão trair, revela estudo
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 sm:p-6 pt-0">
                  <CardDescription className="mb-3 sm:mb-4 text-orange-100 leading-relaxed text-sm">
                    Investigação com mais de 10 mil pessoas mostra os padrões de comportamento mais comuns em casos de
                    infidelidade.
                  </CardDescription>
                  <div className="flex items-center justify-between text-xs sm:text-sm text-orange-200">
                    <span>Por Prof. Carlos Mendes</span>
                    <div className="flex items-center gap-1">
                      <Eye className="h-3 w-3" />
                      <span>4.2k</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>

            {/* Notícia 3 */}
            <Link
              href="/artigo/tecnologia-relacionamentos"
              className="cursor-pointer hover:scale-105 transition-transform"
            >
              <Card className="bg-gradient-to-br from-blue-900/50 to-blue-800/30 border-blue-500/30 backdrop-blur-lg hover:shadow-2xl hover:shadow-blue-500/20 transition-all duration-500">
                <CardHeader className="pb-3 sm:pb-4 p-4 sm:p-6">
                  <div className="flex items-center gap-2 text-xs sm:text-sm text-blue-200 mb-2 sm:mb-3">
                    <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30 text-xs">Tecnologia</Badge>
                    <div className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      <span>6 horas atrás</span>
                    </div>
                  </div>
                  <CardTitle className="text-base sm:text-lg lg:text-xl leading-tight text-white">
                    Tecnologia pode salvar seu relacionamento: como descobrir a verdade sem brigas
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 sm:p-6 pt-0">
                  <CardDescription className="mb-3 sm:mb-4 text-blue-100 leading-relaxed text-sm">
                    Novas ferramentas digitais ajudam casais a reconstruir a confiança de forma inteligente e discreta.
                  </CardDescription>
                  <div className="flex items-center justify-between text-xs sm:text-sm text-blue-200">
                    <span>Por Tech Relacionamentos</span>
                    <div className="flex items-center gap-1">
                      <Eye className="h-3 w-3" />
                      <span>2.9k</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          </div>
        </section>

        {/* Relatos Reais */}
        <section className="mb-12 sm:mb-16">
          <div className="text-center mb-8 sm:mb-12 px-3">
            <h2 className="text-xl sm:text-3xl lg:text-4xl font-bold text-white mb-3 sm:mb-4">
              Relatos Reais de Pessoas que Descobriram a Verdade
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8">
            {/* Relato 1 */}
            <Card className="bg-gradient-to-br from-blue-900/50 to-blue-800/30 border-blue-500/30 backdrop-blur-lg hover:shadow-xl transition-all duration-300">
              <CardHeader className="p-4 sm:p-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center flex-shrink-0">
                    <Users className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
                  </div>
                  <div className="min-w-0">
                    <CardTitle className="text-base sm:text-lg text-white">Ana Carolina, 28 anos</CardTitle>
                    <CardDescription className="text-blue-200 text-sm">São Paulo, SP</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-4 sm:p-6 pt-0">
                <p className="text-blue-100 italic leading-relaxed text-sm">
                  "Descobri que meu namorado estava mentindo sobre onde passava as noites. Ele dizia que estava no
                  trabalho, mas estava em outro lugar. A verdade me libertou."
                </p>
              </CardContent>
            </Card>

            {/* Relato 2 */}
            <Card className="bg-gradient-to-br from-green-900/50 to-green-800/30 border-green-500/30 backdrop-blur-lg hover:shadow-xl transition-all duration-300">
              <CardHeader className="p-4 sm:p-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center flex-shrink-0">
                    <Heart className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
                  </div>
                  <div className="min-w-0">
                    <CardTitle className="text-base sm:text-lg text-white">Roberto Silva, 35 anos</CardTitle>
                    <CardDescription className="text-green-200 text-sm">Rio de Janeiro, RJ</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-4 sm:p-6 pt-0">
                <p className="text-green-100 italic leading-relaxed text-sm">
                  "Minha esposa sempre desconfiava de mim sem motivo. Quando consegui provar onde eu realmente estava,
                  nosso casamento melhorou 100%."
                </p>
              </CardContent>
            </Card>

            {/* Relato 3 */}
            <Card className="bg-gradient-to-br from-purple-900/50 to-purple-800/30 border-purple-500/30 backdrop-blur-lg hover:shadow-xl transition-all duration-300">
              <CardHeader className="p-4 sm:p-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-r from-purple-500 to-violet-500 rounded-full flex items-center justify-center flex-shrink-0">
                    <Shield className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
                  </div>
                  <div className="min-w-0">
                    <CardTitle className="text-base sm:text-lg text-white">Mariana Costa, 31 anos</CardTitle>
                    <CardDescription className="text-purple-200 text-sm">Belo Horizonte, MG</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-4 sm:p-6 pt-0">
                <p className="text-purple-100 italic leading-relaxed text-sm">
                  "Passei 2 anos vivendo na incerteza. Quando finalmente descobri a verdade sobre meu parceiro, pude
                  tomar a decisão certa para minha vida."
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Call to Action */}
        <section className="text-center relative px-3">
          <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-3xl blur-3xl"></div>

          <Card className="bg-gradient-to-r from-purple-900/80 to-pink-900/80 border-purple-500/30 backdrop-blur-xl shadow-2xl max-w-5xl mx-auto relative z-10">
            <CardHeader className="pb-4 sm:pb-6 p-6 sm:p-8">
              <div className="flex justify-center mb-4 sm:mb-6">
                <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                  <Target className="h-6 w-6 sm:h-8 sm:w-8 text-white" />
                </div>
              </div>
              <CardTitle className="text-xl sm:text-3xl lg:text-4xl font-bold mb-3 sm:mb-4 text-white">
                Como Mudar Isso e Ter um Relacionamento Saudável?
              </CardTitle>
              <CardDescription className="text-purple-100 text-base sm:text-lg lg:text-xl leading-relaxed max-w-3xl mx-auto">
                Descubra uma forma inteligente e discreta de reconstruir a confiança no seu relacionamento. Veja como
                funciona nossa plataforma avançada.
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-0 p-6 sm:p-8">
              <Link href="/demonstracao" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold px-6 sm:px-12 py-3 sm:py-6 text-base sm:text-xl rounded-full shadow-2xl hover:shadow-purple-500/50 transition-all duration-300 transform hover:scale-105 mb-6 sm:mb-8 w-full sm:w-auto"
                >
                  Acessar Plataforma
                </Button>
              </Link>

              <Separator className="bg-purple-400/30 mb-4 sm:mb-6" />

              <div className="flex flex-wrap justify-center gap-3 sm:gap-8 text-purple-100">
                <div className="flex items-center gap-2">
                  <Shield className="h-4 w-4 text-green-400" />
                  <span className="text-xs sm:text-base">Segurança Total</span>
                </div>
                <div className="flex items-center gap-2">
                  <Shield className="h-4 w-4 text-blue-400" />
                  <span className="text-xs sm:text-base">100% Discreto</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4 text-purple-400" />
                  <span className="text-xs sm:text-base">Acesso Imediato</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-black/20 backdrop-blur-lg border-t border-white/10 py-6 sm:py-8 mt-12 sm:mt-16">
        <div className="container mx-auto px-3 sm:px-4 text-center">
          <div className="flex justify-center items-center gap-2 sm:gap-3 mb-3 sm:mb-4">
            <div className="w-6 h-6 sm:w-8 sm:h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
              <Sparkles className="h-3 w-3 sm:h-5 sm:w-5 text-white" />
            </div>
            <span className="text-white font-semibold text-sm sm:text-base">Link Mágico</span>
          </div>
          <p className="text-gray-400 text-xs sm:text-sm">
            © 2024 Link Mágico - Tecnologia Avançada para Relacionamentos
          </p>
        </div>
      </footer>
    </div>
  )
}
